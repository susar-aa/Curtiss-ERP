<?php
require_once '../config/db.php';
require_once '../includes/auth_check.php';
requireRole(['rep']); // Strictly for Sales Reps

$rep_id = $_SESSION['user_id'];

// Check if Day is Started
$routeStmt = $pdo->prepare("SELECT id FROM rep_routes WHERE rep_id = ? AND assign_date = CURDATE() AND status = 'accepted' AND start_meter IS NOT NULL ORDER BY id DESC LIMIT 1");
$routeStmt->execute([$rep_id]);
$assignment_id = $routeStmt->fetchColumn();

$vehicle_stock = [];

if ($assignment_id) {
    // Fetch Loaded Stock minus Sold Stock for today's assignment
    $stockQuery = "
        SELECT 
            p.name, p.sku, 
            rl.loaded_qty,
            COALESCE((
                SELECT SUM(oi.quantity) 
                FROM order_items oi 
                JOIN orders o ON oi.order_id = o.id 
                WHERE o.assignment_id = ? AND oi.product_id = p.id
            ), 0) as sold_qty
        FROM route_loads rl
        JOIN products p ON rl.product_id = p.id
        WHERE rl.assignment_id = ?
        ORDER BY p.name ASC
    ";
    $stmt = $pdo->prepare($stockQuery);
    $stmt->execute([$assignment_id, $assignment_id]);
    $vehicle_stock = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Vehicle Stock - Rep App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body { background-color: #f4f7f6; font-family: 'Segoe UI', sans-serif; }
        .top-nav { background: #fff; padding: 15px 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); position: sticky; top: 0; z-index: 1000; display: flex; align-items: center; }
        .back-btn { color: #333; font-size: 1.2rem; text-decoration: none; margin-right: 15px; }
        .stock-card { background: #fff; border-radius: 12px; padding: 15px; margin-bottom: 12px; box-shadow: 0 2px 5px rgba(0,0,0,0.02); }
        .progress { height: 8px; border-radius: 4px; }
    </style>
</head>
<body>

    <div class="top-nav">
        <a href="dashboard.php" class="back-btn"><i class="bi bi-arrow-left"></i></a>
        <h5 class="mb-0 fw-bold">Live Vehicle Stock</h5>
    </div>

    <div class="container px-3 mt-4 pb-5">
        <?php if (!$assignment_id): ?>
            <div class="alert alert-warning border-0 shadow-sm rounded-4 text-center p-4">
                <i class="bi bi-truck fs-1 d-block mb-2 text-warning"></i>
                <h6 class="fw-bold">No Active Vehicle</h6>
                <p class="small mb-0">You must accept a route and enter your start meter before you can view your vehicle stock.</p>
                <a href="dashboard.php" class="btn btn-primary mt-3 rounded-pill px-4">Go to Dashboard</a>
            </div>
        <?php elseif (empty($vehicle_stock)): ?>
            <div class="alert alert-info border-0 shadow-sm rounded-4 text-center p-4">
                <i class="bi bi-box-seam fs-1 d-block mb-2 text-info"></i>
                <h6 class="fw-bold">Vehicle is Empty</h6>
                <p class="small mb-0">Your dispatch manifest does not contain any products.</p>
            </div>
        <?php else: ?>
            
            <!-- Live Search Bar -->
            <div class="d-flex shadow-sm rounded-pill overflow-hidden bg-white mb-4 border">
                <span class="ps-3 pe-2 py-2 text-muted d-flex align-items-center"><i class="bi bi-search"></i></span>
                <input type="text" id="stockSearchInput" class="form-control border-0 shadow-none ps-1 py-2" placeholder="Search product or SKU...">
            </div>

            <p class="text-muted small fw-bold text-uppercase mb-3 px-1">Current Inventory Status</p>

            <div id="stockList">
                <?php foreach ($vehicle_stock as $item): 
                    $remaining = $item['loaded_qty'] - $item['sold_qty'];
                    $sold_percent = ($item['loaded_qty'] > 0) ? ($item['sold_qty'] / $item['loaded_qty']) * 100 : 0;
                    
                    if ($remaining <= 0) { $statusColor = 'danger'; $statusText = 'Out of Stock'; }
                    elseif ($sold_percent >= 80) { $statusColor = 'warning'; $statusText = 'Low Stock'; }
                    else { $statusColor = 'success'; $statusText = 'In Stock'; }
                ?>
                <div class="stock-card">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <div>
                            <h6 class="fw-bold mb-1 text-dark prod-name" style="font-size: 0.95rem;"><?php echo htmlspecialchars($item['name']); ?></h6>
                            <small class="text-muted prod-sku">SKU: <?php echo htmlspecialchars($item['sku'] ?: 'N/A'); ?></small>
                        </div>
                        <span class="badge bg-<?php echo $statusColor; ?> bg-opacity-10 text-<?php echo $statusColor; ?> border border-<?php echo $statusColor; ?>"><?php echo $statusText; ?></span>
                    </div>
                    
                    <div class="d-flex justify-content-between text-muted small fw-bold mb-1 mt-3">
                        <span>Sold: <?php echo $item['sold_qty']; ?></span>
                        <span>Loaded: <?php echo $item['loaded_qty']; ?></span>
                    </div>
                    
                    <div class="progress mb-2 bg-light border">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: <?php echo $sold_percent; ?>%"></div>
                    </div>
                    
                    <div class="text-end">
                        <span class="fw-bold fs-5 text-<?php echo $statusColor; ?>"><?php echo $remaining; ?> <small class="text-muted fs-6">Remaining</small></span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div id="noResultsMsg" class="alert alert-light border shadow-sm rounded-4 text-center p-3 d-none">
                <i class="bi bi-search fs-3 d-block mb-1 text-muted"></i>
                <small class="fw-bold text-muted">No products match your search.</small>
            </div>
            
        <?php endif; ?>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('stockSearchInput');
        if(searchInput) {
            searchInput.addEventListener('input', function() {
                const term = this.value.toLowerCase();
                let visibleCount = 0;
                
                document.querySelectorAll('.stock-card').forEach(card => {
                    const text = card.innerText.toLowerCase();
                    if(text.includes(term)) {
                        card.style.display = 'block';
                        visibleCount++;
                    } else {
                        card.style.display = 'none';
                    }
                });
                
                const noResults = document.getElementById('noResultsMsg');
                if(visibleCount === 0 && term !== '') {
                    noResults.classList.remove('d-none');
                } else {
                    noResults.classList.add('d-none');
                }
            });
        }
    });
    </script>
</body>
</html>