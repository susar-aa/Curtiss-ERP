<?php
require_once '../config/db.php';
require_once '../includes/auth_check.php';
requireRole(['rep']); // Strictly for Sales Reps

$rep_id = $_SESSION['user_id'];
$auto_select_customer = isset($_GET['customer_id']) ? $_GET['customer_id'] : '';
$is_general = isset($_GET['general']) && $_GET['general'] == 'true';

// --- 1. Fetch Edit Data (If applicable) ---
$edit_mode = false;
$edit_order_data = 'null';
$order_assignment_id = null;

if (isset($_GET['edit_id'])) {
    $edit_id = (int)$_GET['edit_id'];
    $stmt = $pdo->prepare("
        SELECT o.*, c.email as customer_email 
        FROM orders o 
        LEFT JOIN customers c ON o.customer_id = c.id 
        WHERE o.id = ? AND o.rep_id = ?
    ");
    $stmt->execute([$edit_id, $rep_id]);
    $order = $stmt->fetch();
    
    if ($order) {
        $edit_mode = true;
        $order_assignment_id = $order['assignment_id'];
        
        $itemsStmt = $pdo->prepare("
            SELECT oi.*, p.name as product_name, p.sku, p.category_id 
            FROM order_items oi 
            JOIN products p ON oi.product_id = p.id 
            WHERE oi.order_id = ?
        ");
        $itemsStmt->execute([$edit_id]);
        $items = $itemsStmt->fetchAll();
        
        // Fetch Cheque details if any exist for this order
        $chkStmt = $pdo->prepare("SELECT * FROM cheques WHERE order_id = ?");
        $chkStmt->execute([$edit_id]);
        $cheque = $chkStmt->fetch();
        
        $cart = [];
        foreach($items as $i) {
            $cart[] = [
                'product_id' => $i['product_id'],
                'supplier_id' => $i['supplier_id'],
                'category_id' => $i['category_id'],
                'name' => $i['product_name'],
                'sku' => $i['sku'],
                'sell_price' => (float)$i['price'],
                'quantity' => (int)$i['quantity'],
                'dis_type' => 'Rs',
                'dis_value' => (float)$i['discount'],
                'is_foc' => (bool)$i['is_foc'],
                'promo_id' => $i['promo_id'] ? (int)$i['promo_id'] : null
            ];
        }
        
        $editDataObj = [
            'order_id' => $order['id'],
            'customer_id' => $order['customer_id'],
            'customer_email' => $order['customer_email'] ?? '',
            'payment_method' => $order['payment_method'],
            'paid_amount' => (float)$order['paid_amount'],
            'paid_cash' => (float)$order['paid_cash'],
            'paid_bank' => (float)$order['paid_bank'],
            'paid_cheque' => (float)$order['paid_cheque'],
            'bill_discount' => (float)$order['discount_amount'],
            'tax_amount' => (float)$order['tax_amount'],
            'cheque' => $cheque ? [
                'bank' => $cheque['bank_name'],
                'number' => $cheque['cheque_number'],
                'date' => $cheque['banking_date']
            ] : null,
            'cart' => $cart
        ];
        $edit_order_data = json_encode($editDataObj);
    }
}

// --- 2. Verify Active Route / Edit Eligibility ---
$assignment_id = null;
$route_id = null;
$block_message = "";

if ($edit_mode) {
    if (is_null($order_assignment_id)) {
        // Editing a General Invoice (No route)
        $is_general = true;
    } else {
        // Editing an existing route order - fetch its assignment
        $asgStmt = $pdo->prepare("SELECT route_id, status FROM rep_routes WHERE id = ?");
        $asgStmt->execute([$order_assignment_id]);
        $asgInfo = $asgStmt->fetch();

        if ($asgInfo && $asgInfo['status'] === 'unloaded') {
            $block_message = "This route has already been unloaded and verified by the admin. You can no longer edit this invoice.";
        } else {
            // Safe to edit
            $assignment_id = $order_assignment_id;
            $route_id = $asgInfo['route_id'] ?? null;
        }
    }
} else {
    // New Order - Check if we are intentionally creating a General Invoice
    if (!$is_general) {
        // Check for active route today
        $routeStmt = $pdo->prepare("SELECT id, route_id, status FROM rep_routes WHERE rep_id = ? AND assign_date = CURDATE() AND status = 'accepted' AND start_meter IS NOT NULL ORDER BY id DESC LIMIT 1");
        $routeStmt->execute([$rep_id]);
        $routeInfo = $routeStmt->fetch();

        if ($routeInfo) {
            $assignment_id = $routeInfo['id'];
            $route_id = $routeInfo['route_id'];
        } else {
            $block_message = "You must accept today's dispatched route and enter your start meter before you can sell from vehicle stock. (Or select 'General Invoice' to sell from main inventory).";
        }
    }
}

// --- 3. Fetch Customers ---
$my_customers = [];
$whereSql = "1=1";
$params = [];

if (!$is_general) {
    if ($route_id && $auto_select_customer !== '') {
        $whereSql = "c.route_id = ? OR c.id = ?";
        $params = [$route_id, (int)$auto_select_customer];
    } elseif ($route_id) {
        $whereSql = "c.route_id = ?";
        $params = [$route_id];
    } elseif ($auto_select_customer !== '') {
        $whereSql = "c.id = ?";
        $params = [(int)$auto_select_customer];
    }
}

$customers = $pdo->prepare("
    SELECT c.id, c.name, c.address, c.phone, c.email,
           (SELECT COALESCE(SUM(total_amount - paid_amount), 0) FROM orders WHERE customer_id = c.id) as outstanding
    FROM customers c WHERE $whereSql ORDER BY c.name ASC
");
$customers->execute($params);
$my_customers = $customers->fetchAll();


// --- 4. Fetch Available Stock (Vehicle vs General) ---
$vehicle_stock = [];
if ($assignment_id) {
    // Fetch Route Stock
    $stockQuery = "
        SELECT 
            p.id as product_id, p.name, p.sku, p.selling_price, p.supplier_id, p.category_id,
            rl.loaded_qty,
            (rl.loaded_qty - COALESCE((
                SELECT SUM(oi.quantity) 
                FROM order_items oi 
                JOIN orders o ON oi.order_id = o.id 
                WHERE o.assignment_id = ? AND oi.product_id = p.id
            ), 0)) as remaining_qty
        FROM route_loads rl
        JOIN products p ON rl.product_id = p.id
        WHERE rl.assignment_id = ?
        HAVING remaining_qty > 0
        ORDER BY p.name ASC
    ";
    $stmt = $pdo->prepare($stockQuery);
    $stmt->execute([$assignment_id, $assignment_id]);
    $vehicle_stock = $stmt->fetchAll();
} elseif ($is_general) {
    // Fetch Main Inventory Stock
    $stockQuery = "
        SELECT 
            p.id as product_id, p.name, p.sku, p.selling_price, p.supplier_id, p.category_id,
            p.stock as loaded_qty,
            p.stock as remaining_qty
        FROM products p
        WHERE p.status = 'available' AND p.stock > 0
        ORDER BY p.name ASC
    ";
    $stmt = $pdo->prepare($stockQuery);
    $stmt->execute();
    $vehicle_stock = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Mobile POS - Rep App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <style>
        body { background-color: #f4f7f6; font-family: 'Segoe UI', sans-serif; padding-bottom: 90px; }
        
        .top-nav { background: #0d6efd; color: white; padding: 15px 20px; position: sticky; top: 0; z-index: 1000; box-shadow: 0 4px 15px rgba(13,110,253,0.2); }
        .back-btn { color: white; font-size: 1.2rem; text-decoration: none; margin-right: 15px; cursor: pointer; }
        
        .section-title { font-size: 0.8rem; font-weight: 700; color: #6c757d; text-transform: uppercase; margin-bottom: 10px; margin-top: 20px; padding-left: 5px; }
        
        .list-card { background: white; border-radius: 16px; padding: 15px; margin-bottom: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); border: 1px solid #f8f9fa; cursor: pointer; transition: transform 0.1s; }
        .list-card:active { transform: scale(0.98); background-color: #f8f9fa; }
        
        .customer-sticky-card { background: #fff; border-bottom: 1px solid #dee2e6; box-shadow: 0 4px 10px rgba(0,0,0,0.03); margin: -1rem -1rem 1rem -1rem; padding: 1rem; position: sticky; top: 55px; z-index: 999; }
        
        .product-card { background: white; border-radius: 12px; padding: 12px; margin-bottom: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.02); display: flex; justify-content: space-between; align-items: center; border: 1px solid #eee; }
        .qty-controls { display: flex; align-items: center; background: #f8f9fa; border-radius: 50px; padding: 3px; border: 1px solid #dee2e6; }
        .qty-btn { background: white; border: none; width: 30px; height: 30px; border-radius: 50%; font-weight: bold; color: #0d6efd; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .qty-display { width: 35px; text-align: center; font-weight: bold; font-size: 0.9rem; border: none; background: transparent; padding: 0; }
        
        .floating-cart-btn { position: fixed; bottom: 20px; left: 20px; right: 20px; background: #198754; color: white; border-radius: 16px; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 8px 20px rgba(25,135,84,0.3); z-index: 1000; text-decoration: none; border: none; width: calc(100% - 40px); }
        .floating-cart-btn:active { transform: scale(0.98); }
        
        /* Enlarged Offcanvas */
        .offcanvas-bottom { border-radius: 0 !important; height: 100vh !important; max-height: 100vh !important; display: flex; flex-direction: column; }
        .offcanvas-body { overflow-y: auto; flex-grow: 1; }
        
        .checkout-summary-row { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 0.95rem; }
        .checkout-summary-total { font-size: 1.5rem; font-weight: 800; border-top: 1px solid #dee2e6; padding-top: 10px; margin-top: 10px; color: #198754; }
        
        .cart-item { padding: 10px 0; border-bottom: 1px dashed #dee2e6; }
        .cart-item:last-child { border-bottom: none; }

        /* Payment Inputs styling */
        .pay-input { text-align: right; font-weight: bold; font-size: 1.1rem; }
    </style>
</head>
<body>

    <div class="top-nav d-flex align-items-center">
        <a id="navBackBtn" class="back-btn"><i class="bi bi-arrow-left"></i></a>
        <div>
            <h5 class="mb-0 fw-bold" id="navTitle">Select Customer</h5>
            <?php if($is_general): ?><small class="text-white text-opacity-75">General Invoice (Main Stock)</small><?php endif; ?>
        </div>
    </div>

    <div class="container px-3 mt-3">
        <?php if (!$assignment_id && !$is_general): ?>
            <div class="alert alert-danger border-0 shadow-sm rounded-4 text-center p-4 mt-5">
                <i class="bi bi-x-octagon fs-1 d-block mb-2"></i>
                <h6 class="fw-bold">Cannot Create/Edit Invoice</h6>
                <p class="small mb-0"><?php echo htmlspecialchars($block_message); ?></p>
                <a href="dashboard.php" class="btn btn-outline-danger mt-3 rounded-pill px-4 fw-bold">Return Home</a>
            </div>
        <?php else: ?>

            <!-- Edit Mode Banner -->
            <?php if($edit_mode): ?>
                <div class="alert alert-warning py-2 mb-3 fw-bold border-warning text-dark shadow-sm rounded-4 text-center">
                    <i class="bi bi-pencil-square"></i> EDITING INVOICE #<?php echo str_pad($edit_id, 6, '0', STR_PAD_LEFT); ?>
                </div>
            <?php endif; ?>

            <!-- ================= VIEW 1: CUSTOMER SELECTION ================= -->
            <div id="view-customer-selection">
                <div class="d-flex shadow-sm rounded-pill overflow-hidden bg-white mb-4 border">
                    <span class="ps-3 pe-2 py-2 text-muted d-flex align-items-center"><i class="bi bi-search"></i></span>
                    <input type="text" id="custSearchInput" class="form-control border-0 shadow-none ps-1 py-2" placeholder="Search customers...">
                </div>

                <div id="customersList">
                    <!-- Walk-in Option -->
                    <div class="list-card d-flex align-items-center cust-card-btn" data-id="0" data-name="Walk-in Customer" data-address="" data-outstanding="0" data-email="">
                        <div class="bg-secondary bg-opacity-10 text-secondary rounded-circle d-flex align-items-center justify-content-center me-3 flex-shrink-0" style="width: 45px; height: 45px; font-size: 1.2rem;">
                            <i class="bi bi-person-walking"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold mb-0 text-dark">Walk-in Customer</h6>
                            <small class="text-muted">Unregistered client</small>
                        </div>
                        <i class="bi bi-chevron-right ms-auto text-muted opacity-50"></i>
                    </div>

                    <!-- Customers Loop -->
                    <?php foreach($my_customers as $c): ?>
                    <div class="list-card cust-card cust-card-btn" data-id="<?php echo $c['id']; ?>" data-name="<?php echo htmlspecialchars($c['name'], ENT_QUOTES); ?>" data-address="<?php echo htmlspecialchars($c['address'] ?? '', ENT_QUOTES); ?>" data-outstanding="<?php echo $c['outstanding']; ?>" data-email="<?php echo htmlspecialchars($c['email'] ?? '', ENT_QUOTES); ?>">
                        <div class="d-flex align-items-start">
                            <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center me-3 flex-shrink-0" style="width: 45px; height: 45px; font-size: 1.2rem;">
                                <i class="bi bi-shop"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="fw-bold mb-1 text-dark cust-name"><?php echo htmlspecialchars($c['name']); ?></h6>
                                <div class="small text-muted mb-1 cust-address text-truncate" style="max-width: 200px;"><i class="bi bi-geo-alt"></i> <?php echo htmlspecialchars($c['address'] ?: 'No Address'); ?></div>
                                <?php if($c['outstanding'] > 0): ?>
                                    <span class="badge bg-danger bg-opacity-10 text-danger border border-danger fw-bold"><i class="bi bi-exclamation-circle"></i> Ows: Rs. <?php echo number_format($c['outstanding'], 2); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- ================= VIEW 2: ORDER ENTRY ================= -->
            <div id="view-order-entry" class="d-none">
                
                <!-- Sticky Customer Info -->
                <div class="customer-sticky-card">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <span class="badge bg-primary mb-1">Billing To:</span>
                            <h5 class="fw-bold mb-0 text-dark" id="selectedCustName">Customer Name</h5>
                            <!-- Outstanding Alert -->
                            <div id="selectedCustOut" class="text-danger fw-bold small mt-1 d-none"><i class="bi bi-exclamation-circle"></i> Prior Outstanding: Rs <span id="valCustOut">0.00</span></div>
                        </div>
                        <button class="btn btn-sm btn-outline-secondary rounded-pill fw-bold shadow-sm" onclick="showCustomerView()">Change</button>
                    </div>
                </div>

                <!-- Product Search -->
                <div class="d-flex shadow-sm rounded-pill overflow-hidden bg-white mb-3 mt-3 border">
                    <span class="ps-3 pe-2 py-2 text-muted d-flex align-items-center"><i class="bi bi-search"></i></span>
                    <input type="text" id="prodSearchInput" class="form-control border-0 shadow-none ps-1 py-2" placeholder="Search available stock...">
                </div>

                <h6 class="text-muted small fw-bold text-uppercase px-1 mb-2">Available Products</h6>

                <!-- Products Grid -->
                <div id="productsList">
                    <?php if(empty($vehicle_stock)): ?>
                        <div class="alert alert-warning text-center small fw-bold rounded-4 shadow-sm border-0 py-4"><i class="bi bi-box-seam fs-2 d-block mb-2"></i> No stock is available!</div>
                    <?php else: ?>
                        <?php foreach($vehicle_stock as $p): ?>
                        <div class="product-card prod-card" onclick='openProductModal(<?php echo json_encode($p, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)' style="cursor: pointer;">
                            <div style="flex: 1; padding-right: 10px;">
                                <h6 class="fw-bold text-dark mb-1 prod-name" style="font-size: 0.95rem; line-height: 1.2;"><?php echo htmlspecialchars($p['name']); ?></h6>
                                <div class="d-flex align-items-center mt-1">
                                    <span class="fw-bold text-success me-2">Rs. <?php echo number_format($p['selling_price'], 2); ?></span>
                                    <span class="badge bg-secondary bg-opacity-10 text-secondary border"><?php echo $is_general ? 'WH' : 'Van'; ?>: <?php echo $p['remaining_qty']; ?></span>
                                </div>
                                <div class="d-none prod-sku"><?php echo htmlspecialchars($p['sku']); ?></div>
                            </div>
                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center shadow-sm" style="width: 35px; height: 35px; flex-shrink: 0;">
                                <i class="bi bi-plus-lg"></i>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

        <?php endif; ?>
    </div>

    <!-- UI Elements Protected by Assignment ID or General Mode -->
    <?php if ($assignment_id || $is_general): ?>
        
        <!-- Floating Checkout Button -->
        <button type="button" class="floating-cart-btn d-none" data-bs-toggle="offcanvas" data-bs-target="#checkoutCanvas" id="mainCheckoutBtn">
            <div class="d-flex align-items-center">
                <div class="bg-white text-success rounded-circle d-flex align-items-center justify-content-center fw-bold me-2" style="width: 30px; height: 30px;" id="cartItemCount">0</div>
                <span class="fw-bold">Review Cart</span>
            </div>
            <div class="fw-bold fs-5">Rs <span id="cartTotalBtn">0.00</span></div>
        </button>

        <!-- ================= MODALS & OFFCANVAS ================= -->

        <!-- Product Entry Modal -->
        <div class="modal fade" id="productModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 rounded-4 shadow">
                    <div class="modal-header bg-light border-bottom-0 pb-2">
                        <h5 class="modal-title fw-bold text-dark" id="modalProdName">Product Name</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body pt-0">
                        <div class="text-muted small mb-3">Available Stock: <span id="modalProdStock" class="fw-bold text-primary">0</span></div>
                        
                        <div class="row g-3">
                            <div class="col-6">
                                <label class="form-label fw-bold small text-muted">Quantity</label>
                                <input type="number" id="modalQty" class="form-control form-control-lg fw-bold text-center" value="1" min="1">
                            </div>
                            <div class="col-6">
                                <label class="form-label fw-bold small text-muted">Unit Price (Rs)</label>
                                <input type="number" id="modalPrice" class="form-control form-control-lg fw-bold text-success text-center" step="0.01">
                            </div>
                            
                            <div class="col-12 mt-2">
                                <label class="form-label fw-bold small text-muted">Item Discount (Optional)</label>
                                <div class="input-group input-group-lg shadow-sm border rounded">
                                    <select id="modalDisType" class="form-select bg-light fw-bold border-0" style="max-width: 90px;">
                                        <option value="%">%</option>
                                        <option value="Rs">Rs</option>
                                    </select>
                                    <input type="number" id="modalDisValue" class="form-control fw-bold text-danger border-0" value="0" min="0" step="0.01">
                                </div>
                            </div>
                            
                            <!-- MANUAL FOC SWITCH -->
                            <div class="col-12 mt-3">
                                <div class="form-check form-switch bg-danger bg-opacity-10 border border-danger border-opacity-25 rounded-pill p-2 ps-5 shadow-sm">
                                    <input class="form-check-input fs-4 mt-0" type="checkbox" id="isManualFoc" style="margin-left: -2.5rem; cursor: pointer;">
                                    <label class="form-check-label fw-bold text-danger ms-2 pt-1" for="isManualFoc" style="cursor: pointer;">Issue as Free Item (FOC)</label>
                                </div>
                            </div>
                        </div>

                        <div class="bg-light p-3 rounded-4 mt-4 d-flex justify-content-between align-items-center border">
                            <span class="fw-bold text-muted">Item Net Total:</span>
                            <span class="fs-4 fw-bold text-dark">Rs <span id="modalNetTotal">0.00</span></span>
                        </div>
                    </div>
                    <div class="modal-footer border-top-0 pt-0">
                        <button type="button" class="btn btn-primary btn-lg w-100 rounded-pill fw-bold shadow-sm" id="btnAddToCart">Add to Bill</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- FULL SCREEN Checkout Offcanvas -->
        <div class="offcanvas offcanvas-bottom" tabindex="-1" id="checkoutCanvas">
            <div class="offcanvas-header bg-light border-bottom">
                <h5 class="offcanvas-title fw-bold"><i class="bi bi-cart-check text-success"></i> Checkout Summary</h5>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
            </div>
            <div class="offcanvas-body px-3 pb-4 bg-white">
                
                <!-- Cart Items Preview -->
                <div class="bg-light p-2 rounded-4 shadow-sm border mb-3">
                    <div id="cartItemsPreview" style="max-height: 150px; overflow-y: auto;">
                        <!-- Filled by JS -->
                    </div>
                </div>

                <!-- Discount & Tax Row -->
                <div class="bg-light p-3 rounded-4 shadow-sm border mb-3">
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label fw-bold small text-muted mb-1">Bill Discount</label>
                            <div class="input-group input-group-sm">
                                <select id="billDisType" class="form-select bg-white fw-bold border" style="max-width: 60px;">
                                    <option value="%">%</option>
                                    <option value="Rs">Rs</option>
                                </select>
                                <input type="number" id="billDisValue" class="form-control text-danger fw-bold text-end border" value="0" min="0" step="0.01">
                            </div>
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold small text-muted mb-1">Tax / VAT</label>
                            <div class="input-group input-group-sm">
                                <select id="taxDisType" class="form-select bg-white fw-bold border" style="max-width: 60px;">
                                    <option value="%">%</option>
                                    <option value="Rs">Rs</option>
                                </select>
                                <input type="number" id="taxDisValue" class="form-control fw-bold text-end border" value="0" min="0" step="0.01">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Summary Totals -->
                <div class="bg-light p-3 rounded-4 shadow-sm border border-primary mb-3">
                    <div class="checkout-summary-row text-muted">
                        <span>Subtotal</span>
                        <span class="fw-bold text-dark">Rs <span id="sumSubtotal">0.00</span></span>
                    </div>
                    <div id="sumDisRow" class="checkout-summary-row text-danger d-none">
                        <span>Total Discount</span>
                        <span class="fw-bold">- Rs <span id="sumDiscount">0.00</span></span>
                    </div>
                    <div class="checkout-summary-row text-primary fw-bold border-top pt-2 mt-2">
                        <span>Current Bill</span>
                        <span>Rs <span id="sumNet">0.00</span></span>
                    </div>
                    <div class="checkout-summary-row text-danger d-none" id="sumOutRow">
                        <span>Prior Outstanding</span>
                        <span class="fw-bold">+ Rs <span id="sumOutstanding">0.00</span></span>
                    </div>
                    <div class="checkout-summary-row checkout-summary-total">
                        <span>TOTAL PAYABLE</span>
                        <span>Rs <span id="sumTotalPayable">0.00</span></span>
                    </div>
                </div>

                <!-- Split Payments Section -->
                <h6 class="fw-bold text-muted small text-uppercase mb-2 px-1">Payment Received</h6>
                <div class="bg-light p-3 rounded-4 shadow-sm border mb-3">
                    
                    <div class="row align-items-center mb-2">
                        <div class="col-5 fw-bold text-success"><i class="bi bi-cash-stack"></i> Cash</div>
                        <div class="col-7"><input type="number" id="payCash" class="form-control pay-input text-success border-success" placeholder="0.00" min="0" step="0.01"></div>
                    </div>
                    
                    <div class="row align-items-center mb-2">
                        <div class="col-5 fw-bold text-info text-dark"><i class="bi bi-bank"></i> Bank T.</div>
                        <div class="col-7"><input type="number" id="payBank" class="form-control pay-input text-info border-info" placeholder="0.00" min="0" step="0.01"></div>
                    </div>
                    
                    <div class="row align-items-center mb-2">
                        <div class="col-5 fw-bold text-warning text-dark"><i class="bi bi-credit-card-2-front"></i> Cheque</div>
                        <div class="col-7"><input type="number" id="payCheque" class="form-control pay-input text-warning text-dark border-warning" placeholder="0.00" min="0" step="0.01"></div>
                    </div>

                    <!-- Hidden Cheque Details -->
                    <div id="chequeFields" class="bg-white border border-warning rounded p-3 mt-3 d-none shadow-sm">
                        <h6 class="fw-bold mb-2 small text-warning text-dark"><i class="bi bi-info-circle"></i> Cheque Info</h6>
                        <input type="text" id="chkBank" class="form-control form-control-sm mb-2 border-warning" placeholder="Bank Name (e.g. Commercial)">
                        <input type="text" id="chkNum" class="form-control form-control-sm mb-2 border-warning" placeholder="Cheque Number">
                        <input type="date" id="chkDate" class="form-control form-control-sm border-warning">
                    </div>

                    <div class="border-top mt-3 pt-3 d-flex justify-content-between align-items-center">
                        <span class="fw-bold text-muted" id="paymentBalanceLabel">Remaining Due</span>
                        <span class="fw-bold fs-5 text-danger" id="paymentBalance">0.00</span>
                    </div>
                </div>

                <div id="checkoutMessage" class="mt-2"></div>

                <button type="button" id="btnConfirmSale" class="btn btn-primary btn-lg w-100 rounded-pill fw-bold mt-2 shadow-sm py-3 mb-4">
                    <?php echo $edit_mode ? 'Update Order <i class="bi bi-check-circle ms-1"></i>' : 'Complete Order <i class="bi bi-check-circle ms-1"></i>'; ?>
                </button>
            </div>
        </div>

        <!-- Success Output Modal -->
        <div class="modal fade" id="successModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 rounded-4 shadow p-3 text-center">
                    <div class="modal-body">
                        <i class="bi bi-check-circle-fill text-success" style="font-size: 4rem;"></i>
                        <h4 class="fw-bold mt-3">Order Saved!</h4>
                        <p class="text-muted mb-4">Invoice <strong class="text-primary" id="successOrderId">#000000</strong> has been securely saved.</p>

                        <!-- QR Code Container -->
                        <div id="qrContainer" class="d-none bg-light p-3 rounded-4 border mb-4 d-flex justify-content-center">
                            <div id="qrcode"></div>
                        </div>

                        <div class="d-flex gap-2 mb-3 flex-wrap">
                            <button type="button" id="btnShowQR" class="btn btn-outline-dark fw-bold flex-fill rounded-pill py-2">
                                <i class="bi bi-qr-code"></i> Show QR
                            </button>
                            <button type="button" id="btnEmailReceipt" class="btn btn-outline-primary fw-bold flex-fill rounded-pill py-2" style="display: none;">
                                <i class="bi bi-envelope"></i> Email Receipt
                            </button>
                            <button type="button" id="btnPrintInvoice" class="btn btn-success fw-bold flex-fill rounded-pill py-2">
                                <i class="bi bi-printer"></i> Print PDF
                            </button>
                        </div>
                        
                        <a href="dashboard.php" class="btn btn-light text-muted w-100 rounded-pill fw-bold border py-2">Back to Home</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- JS specific to active route -->
        <script>
            window.editInvoiceData = <?php echo $edit_order_data; ?>;
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            
            // --- 1. DOM Elements ---
            const viewCustomer = document.getElementById('view-customer-selection');
            
            if (!viewCustomer) { return; }

            let activePromotions = [];
            let productDb = [];
            let promoState = { applied: {}, rejected: [] }; // Object for applied, array for rejected
            let isEvaluatingPromos = false;

            const viewOrder = document.getElementById('view-order-entry');
            const navTitle = document.getElementById('navTitle');
            const navBackBtn = document.getElementById('navBackBtn');

            const cartBtn = document.getElementById('mainCheckoutBtn');
            const countBadge = document.getElementById('cartItemCount');
            const totalBtnText = document.getElementById('cartTotalBtn');
            
            const sumSubtotal = document.getElementById('sumSubtotal');
            const sumNet = document.getElementById('sumNet');
            const sumDiscount = document.getElementById('sumDiscount');
            const sumDisRow = document.getElementById('sumDisRow');
            
            const sumOutstanding = document.getElementById('sumOutstanding');
            const sumOutRow = document.getElementById('sumOutRow');
            const sumTotalPayable = document.getElementById('sumTotalPayable');
            
            const billDisType = document.getElementById('billDisType');
            const billDisValue = document.getElementById('billDisValue');
            const taxDisType = document.getElementById('taxDisType');
            const taxDisValue = document.getElementById('taxDisValue');

            const payCash = document.getElementById('payCash');
            const payBank = document.getElementById('payBank');
            const payCheque = document.getElementById('payCheque');
            const chequeFields = document.getElementById('chequeFields');

            const prodModal = new bootstrap.Modal(document.getElementById('productModal'));
            const modalQty = document.getElementById('modalQty');
            const modalPrice = document.getElementById('modalPrice');
            const modalDisType = document.getElementById('modalDisType');
            const modalDisValue = document.getElementById('modalDisValue');
            const modalNetTotal = document.getElementById('modalNetTotal');
            const isManualFoc = document.getElementById('isManualFoc'); 

            const custSearchInput = document.getElementById('custSearchInput');
            const prodSearchInput = document.getElementById('prodSearchInput');

            // --- 2. State Variables ---
            let selectedCustomerData = { id: null, name: null, outstanding: 0, email: '' };
            let cart = [];
            let activeProductData = null; 
            let finalOrderId = null;

            // --- FETCH PROMOTIONS API ---
            fetch('../ajax/fetch_promotions.php')
                .then(res => res.json())
                .then(data => {
                    if(data.success) {
                        activePromotions = data.promotions;
                        productDb = data.products;
                        console.log("Rep JSON Tiers Promotions Engine Active:", activePromotions.length, "rules loaded.");
                    }
                }).catch(err => console.error("Error loading promotions engine:", err));

            // --- 3. Function Definitions ---
            window.showCustomerView = function() {
                viewOrder.classList.add('d-none');
                viewCustomer.classList.remove('d-none');
                navTitle.textContent = "Select Customer";
                navBackBtn.removeAttribute('onclick');
                navBackBtn.href = "dashboard.php";
                cartBtn.classList.add('d-none');
            };

            window.selectCustomer = function(id, name, address, outstanding, email = '') {
                if (id === 0 || id === '0') id = null;

                const outValue = parseFloat(outstanding) || 0;

                selectedCustomerData = { id: id, name: name, outstanding: outValue, email: email };
                document.getElementById('selectedCustName').textContent = name;
                
                const outEl = document.getElementById('selectedCustOut');
                if (outValue > 0) {
                    outEl.classList.remove('d-none');
                    document.getElementById('valCustOut').textContent = outValue.toFixed(2);
                } else {
                    outEl.classList.add('d-none');
                }

                viewCustomer.classList.add('d-none');
                viewOrder.classList.remove('d-none');
                navTitle.textContent = "Mobile POS";
                
                navBackBtn.removeAttribute('href');
                navBackBtn.onclick = showCustomerView;
                
                updateCartUI(); 
            };

            window.openProductModal = function(product) {
                activeProductData = product;
                
                document.getElementById('modalProdName').textContent = product.name;
                document.getElementById('modalProdStock').textContent = product.remaining_qty;
                
                isManualFoc.checked = false;
                modalPrice.readOnly = false;
                modalDisValue.readOnly = false;
                
                const existing = cart.find(c => c.product_id == product.product_id && !c.promo_id);
                if (existing) {
                    modalQty.value = existing.quantity;
                    modalPrice.value = parseFloat(existing.sell_price).toFixed(2);
                    modalDisType.value = existing.dis_type;
                    modalDisValue.value = existing.dis_value;
                    if(existing.is_foc) {
                        isManualFoc.checked = true;
                        modalPrice.readOnly = true;
                        modalDisValue.readOnly = true;
                    }
                } else {
                    modalQty.value = 1;
                    modalPrice.value = parseFloat(product.selling_price).toFixed(2);
                    modalDisType.value = '%';
                    modalDisValue.value = 0;
                }
                
                modalQty.max = product.remaining_qty;
                calculateModalNet();
                prodModal.show();
            };

            isManualFoc.addEventListener('change', function() {
                if (this.checked) {
                    modalPrice.value = "0.00";
                    modalDisValue.value = "0";
                    modalPrice.readOnly = true;
                    modalDisValue.readOnly = true;
                } else {
                    if (activeProductData) modalPrice.value = parseFloat(activeProductData.selling_price).toFixed(2);
                    modalPrice.readOnly = false;
                    modalDisValue.readOnly = false;
                }
                calculateModalNet();
            });

            function calculateModalNet() {
                if(!activeProductData) return;
                
                if (isManualFoc.checked) {
                    modalNetTotal.textContent = "0.00";
                    return;
                }

                const qty = parseFloat(modalQty.value) || 0;
                const price = parseFloat(modalPrice.value) || 0;
                const dType = modalDisType.value;
                const dVal = parseFloat(modalDisValue.value) || 0;
                
                const gross = qty * price;
                let disAmt = dType === '%' ? gross * (dVal / 100) : dVal * qty;
                
                modalNetTotal.textContent = (gross - disAmt).toFixed(2);
            }

            window.removeCartItem = function(idx) {
                cart.splice(idx, 1);
                if (window.editInvoiceData === null) {
                    localStorage.setItem('fintrix_rep_pos_cart', JSON.stringify(cart));
                }
                updateCartUI();
            };

            function removePromoFromCart(promoIdNum) {
                cart = cart.filter(item => !(item.is_foc && item.promo_id == promoIdNum));
                cart.forEach(item => {
                    if (item.promo_id == promoIdNum) {
                        item.dis_type = '%'; item.dis_value = 0; item.dis_percent = 0; item.promo_id = null;
                    }
                });
            }

            // =========================================================================
            // SMART PROMOTIONS ENGINE EVALUATOR - UNIFIED PROMPT TIERED
            // =========================================================================
            function evaluatePromotions() {
                if (isEvaluatingPromos || activePromotions.length === 0) return;
                isEvaluatingPromos = true;
                let cartChanged = false;

                let catQty = {}; let catAmt = {};
                let prodQty = {}; let prodAmt = {};

                cart.forEach(item => {
                    if (item.is_foc) return; // Don't trigger rules with FOC items

                    let cid = parseInt(item.category_id);
                    let pid = parseInt(item.product_id);
                    let qty = parseInt(item.quantity);
                    let amt = (item.sell_price * qty) - (item.dis_type === '%' ? (item.sell_price * qty * (item.dis_value/100)) : (item.dis_value * qty));

                    if(cid) { catQty[cid] = (catQty[cid] || 0) + qty; catAmt[cid] = (catAmt[cid] || 0) + amt; }
                    prodQty[pid] = (prodQty[pid] || 0) + qty; prodAmt[pid] = (prodAmt[pid] || 0) + amt;
                });

                let newlyTriggered = [];

                for (const promo of activePromotions) {
                    let tiers = [];
                    try { tiers = JSON.parse(promo.tiers_config); } catch(e) {}
                    if (!tiers || tiers.length === 0) continue;

                    let promoIdNum = parseInt(promo.id);
                    let currentAmt = 0; let currentQty = 0;

                    if (promo.target_category_id) {
                        currentAmt = catAmt[parseInt(promo.target_category_id)] || 0;
                        currentQty = catQty[parseInt(promo.target_category_id)] || 0;
                    } else if (promo.target_product_id) {
                        currentAmt = prodAmt[parseInt(promo.target_product_id)] || 0;
                        currentQty = prodQty[parseInt(promo.target_product_id)] || 0;
                    }

                    let highestTierIndex = -1;
                    let highestTier = null;

                    // Find Highest Tier
                    for (let i = 0; i < tiers.length; i++) {
                        let t = tiers[i];
                        if (promo.promo_type === 'foc' && currentQty >= parseInt(t.min_qty)) {
                            if (highestTierIndex === -1 || parseInt(t.min_qty) > parseInt(highestTier.min_qty)) {
                                highestTierIndex = i; highestTier = t;
                            }
                        } else if (promo.promo_type === 'percentage' && currentAmt >= parseFloat(t.min_amount)) {
                            if (highestTierIndex === -1 || parseFloat(t.min_amount) > parseFloat(highestTier.min_amount)) {
                                highestTierIndex = i; highestTier = t;
                            }
                        }
                    }

                    if (highestTierIndex !== -1) {
                        let currentAppliedTier = promoState.applied[promoIdNum];
                        
                        if (currentAppliedTier !== highestTierIndex && !promoState.rejected.includes(promoIdNum + '_' + highestTierIndex)) {
                            newlyTriggered.push({
                                promo_id: promoIdNum,
                                promo_type: promo.promo_type,
                                tier_index: highestTierIndex,
                                tier: highestTier,
                                target_category_id: promo.target_category_id,
                                target_product_id: promo.target_product_id
                            });
                        }
                    } else {
                        // Dropped below all thresholds
                        if (promoState.applied[promoIdNum] !== undefined) {
                            removePromoFromCart(promoIdNum);
                            delete promoState.applied[promoIdNum];
                            cartChanged = true;
                        }
                    }
                }

                // --- ONE Unified Prompt for ALL newly triggered tiers ---
                if (newlyTriggered.length > 0) {
                    let msg = "🔥 PROMOTIONS TRIGGERED!\n\nThis order reached the tier for:\n";
                    let aggregatedFoc = {};
                    let pctMsgs = [];

                    newlyTriggered.forEach(nt => {
                        if (nt.promo_type === 'foc') {
                            let pid = nt.tier.free_product_id;
                            if(!aggregatedFoc[pid]) aggregatedFoc[pid] = 0;
                            aggregatedFoc[pid] += parseInt(nt.tier.free_qty);
                        } else {
                            pctMsgs.push(`${parseFloat(nt.tier.discount_percent)}% Value Discount`);
                        }
                    });

                    let validPrompt = false;
                    for(let pid in aggregatedFoc) {
                        let freeProd = productDb.find(p => p.id == pid);
                        if(freeProd) {
                            msg += `- ${aggregatedFoc[pid]}x ${freeProd.name} for FREE\n`;
                            validPrompt = true;
                        }
                    }
                    if (pctMsgs.length > 0) {
                        pctMsgs.forEach(m => { msg += `- ${m}\n`; validPrompt = true; });
                    }

                    if (validPrompt) {
                        msg += "\nDo you want to apply these to the bill?";
                        
                        if (confirm(msg)) {
                            newlyTriggered.forEach(nt => {
                                // Crucial: Remove the old tier for THIS promo before applying the new one
                                if (promoState.applied[nt.promo_id] !== undefined) {
                                    removePromoFromCart(nt.promo_id);
                                }

                                // Apply new tier
                                if (nt.promo_type === 'foc') {
                                    let freeProd = productDb.find(p => p.id == nt.tier.free_product_id);
                                    if (freeProd) {
                                        cart.push({
                                            product_id: freeProd.id,
                                            supplier_id: null,
                                            name: freeProd.name,
                                            product_name: freeProd.name,
                                            sku: 'FOC-PROMO',
                                            sell_price: 0,
                                            quantity: parseInt(nt.tier.free_qty),
                                            dis_type: '%',
                                            dis_value: 0,
                                            dis_percent: 0,
                                            max_stock: 9999,
                                            is_foc: true,
                                            promo_id: nt.promo_id,
                                            category_id: freeProd.category_id
                                        });
                                    }
                                } else if (nt.promo_type === 'percentage') {
                                    cart.forEach(item => {
                                        if (!item.is_foc) {
                                            if ((nt.target_category_id && item.category_id == nt.target_category_id) || 
                                                (nt.target_product_id && item.product_id == nt.target_product_id)) {
                                                item.dis_type = '%';
                                                item.dis_value = parseFloat(nt.tier.discount_percent);
                                                item.dis_percent = parseFloat(nt.tier.discount_percent);
                                                item.promo_id = nt.promo_id;
                                            }
                                        }
                                    });
                                }
                                promoState.applied[nt.promo_id] = nt.tier_index;
                            });
                            cartChanged = true;
                        } else {
                            newlyTriggered.forEach(nt => {
                                promoState.rejected.push(nt.promo_id + '_' + nt.tier_index);
                            });
                        }
                    }
                }

                isEvaluatingPromos = false;
                
                if (cartChanged) {
                    if (window.editInvoiceData === null) {
                        localStorage.setItem('fintrix_rep_pos_cart', JSON.stringify(cart));
                    }
                    updateCartUI(); 
                }
            }

            function updateCartUI() {
                const previewBox = document.getElementById('cartItemsPreview');
                previewBox.innerHTML = '';
                
                let subtotal = 0;
                let totalItems = 0;

                cart.forEach((item, idx) => {
                    totalItems++;
                    
                    const gross = item.sell_price * item.quantity;
                    let itemDisAmt = item.dis_type === '%' ? (gross * (item.dis_value / 100)) : (item.dis_value * item.quantity);
                    const lineTotal = gross - itemDisAmt;
                    
                    subtotal += lineTotal;

                    previewBox.innerHTML += `
                        <div class="cart-item d-flex justify-content-between align-items-center">
                            <div>
                                <div class="fw-bold text-dark" style="font-size: 0.9rem;">
                                    ${item.name || item.product_name}
                                    ${item.is_foc ? '<span class="badge bg-danger ms-1 px-1">FOC</span>' : ''}
                                    ${item.promo_id ? '<span class="badge bg-primary ms-1" title="Promo Rule"><i class="bi bi-magic"></i> Tier</span>' : ''}
                                </div>
                                <div class="text-muted" style="font-size: 0.75rem;">${item.quantity}x @ Rs ${parseFloat(item.sell_price).toFixed(2)} ${item.dis_value > 0 ? `(-${item.dis_value}${item.dis_type} dis)` : ''}</div>
                            </div>
                            <div class="text-end">
                                <div class="fw-bold text-success small">Rs ${lineTotal.toFixed(2)}</div>
                                <i class="bi bi-trash text-danger" style="cursor:pointer;" onclick="removeCartItem(${idx})"></i>
                            </div>
                        </div>
                    `;
                });

                if (totalItems > 0) {
                    cartBtn.classList.remove('d-none');
                    countBadge.textContent = totalItems;
                    totalBtnText.textContent = subtotal.toFixed(2);
                } else {
                    cartBtn.classList.add('d-none');
                    const bsOffcanvas = bootstrap.Offcanvas.getInstance(document.getElementById('checkoutCanvas'));
                    if (bsOffcanvas) bsOffcanvas.hide();
                }

                evaluatePromotions();
                calculateFinalTotals(subtotal);
            }

            function calculateFinalTotals(subtotal) {
                sumSubtotal.textContent = subtotal.toFixed(2);
                
                const bDType = billDisType.value;
                const bDVal = parseFloat(billDisValue.value) || 0;
                const tType = taxDisType.value;
                const tVal = parseFloat(taxDisValue.value) || 0;

                let finalBillDiscount = bDType === '%' ? subtotal * (bDVal / 100) : bDVal;
                if (finalBillDiscount > subtotal) finalBillDiscount = subtotal;
                
                let discountedSubtotal = subtotal - finalBillDiscount;
                let finalTax = tType === '%' ? discountedSubtotal * (tVal / 100) : tVal;

                if (finalBillDiscount > 0) {
                    sumDisRow.classList.remove('d-none');
                    sumDiscount.textContent = finalBillDiscount.toFixed(2);
                } else {
                    sumDisRow.classList.add('d-none');
                }

                const netAmount = discountedSubtotal + finalTax;
                sumNet.textContent = netAmount.toFixed(2);
                
                const outstanding = parseFloat(selectedCustomerData.outstanding) || 0;
                sumOutstanding.textContent = outstanding.toFixed(2);
                if (outstanding > 0) {
                    sumOutRow.classList.remove('d-none');
                } else {
                    sumOutRow.classList.add('d-none');
                }

                const totalPayable = netAmount + outstanding;
                sumTotalPayable.textContent = totalPayable.toFixed(2);
                
                window.absoluteBillDiscount = finalBillDiscount; 
                window.absoluteTaxAmount = finalTax;
                window.totalPayable = totalPayable; 

                calculatePaymentBalance();
            }

            function calculatePaymentBalance() {
                const cash = parseFloat(payCash.value) || 0;
                const bank = parseFloat(payBank.value) || 0;
                const cheque = parseFloat(payCheque.value) || 0;

                const totalPaid = cash + bank + cheque;
                const net = window.totalPayable || 0; 
                const balance = totalPaid - net;

                const balanceEl = document.getElementById('paymentBalance');
                const balanceLabel = document.getElementById('paymentBalanceLabel');

                if (balance >= 0) {
                    balanceLabel.textContent = "Change Due";
                    balanceEl.textContent = balance.toFixed(2);
                    balanceEl.className = "fw-bold fs-5 text-dark";
                } else {
                    balanceLabel.textContent = "Remaining Due (Ows)";
                    balanceEl.textContent = Math.abs(balance).toFixed(2);
                    balanceEl.className = "fw-bold fs-5 text-danger";
                }

                if (cheque > 0) {
                    chequeFields.classList.remove('d-none');
                } else {
                    chequeFields.classList.add('d-none');
                }
            }

            // --- 4. Event Listeners ---

            [modalQty, modalPrice, modalDisType, modalDisValue].forEach(el => el.addEventListener('input', calculateModalNet));
            
            [billDisType, billDisValue, taxDisType, taxDisValue].forEach(el => el.addEventListener('input', () => {
                const sub = parseFloat(sumSubtotal.textContent) || 0;
                calculateFinalTotals(sub);
            }));

            [payCash, payBank, payCheque].forEach(el => el.addEventListener('input', calculatePaymentBalance));

            // Click listeners for Customer List
            document.querySelectorAll('.cust-card-btn').forEach(card => {
                card.addEventListener('click', function() {
                    const id = this.dataset.id || null;
                    const name = this.dataset.name;
                    const address = this.dataset.address;
                    const outstanding = parseFloat(this.dataset.outstanding) || 0;
                    const email = this.dataset.email || '';
                    selectCustomer(id, name, address, outstanding, email);
                });
            });

            // Live Searches
            if (custSearchInput) {
                custSearchInput.addEventListener('input', function() {
                    const term = this.value.toLowerCase();
                    document.querySelectorAll('.cust-card').forEach(card => {
                        const text = card.innerText.toLowerCase();
                        card.style.display = text.includes(term) ? 'flex' : 'none';
                    });
                });
            }

            if (prodSearchInput) {
                prodSearchInput.addEventListener('input', function() {
                    const term = this.value.toLowerCase();
                    document.querySelectorAll('.prod-card').forEach(card => {
                        const text = card.innerText.toLowerCase();
                        card.style.display = text.includes(term) ? 'flex' : 'none';
                    });
                });
            }

            document.getElementById('btnAddToCart').addEventListener('click', function() {
                const qty = parseInt(modalQty.value) || 0;
                const price = parseFloat(modalPrice.value) || 0;
                const maxStock = parseInt(activeProductData.remaining_qty);
                const isFoc = isManualFoc.checked;

                if (qty <= 0) { alert('Quantity must be greater than 0.'); return; }
                if (qty > maxStock) { alert(`Only ${maxStock} items available in van.`); return; }

                const existingIdx = cart.findIndex(c => c.product_id == activeProductData.product_id && c.is_foc === isFoc && !c.promo_id);
                
                const cartItem = {
                    product_id: activeProductData.product_id,
                    supplier_id: activeProductData.supplier_id,
                    name: activeProductData.name,
                    sku: activeProductData.sku || 'N/A',
                    category_id: activeProductData.category_id,
                    sell_price: price,
                    quantity: qty,
                    dis_type: modalDisType.value,
                    dis_value: parseFloat(modalDisValue.value) || 0,
                    max_stock: maxStock,
                    is_foc: isFoc,
                    promo_id: null
                };

                if (existingIdx > -1) {
                    cart[existingIdx] = cartItem;
                } else {
                    cart.push(cartItem);
                }

                // Save to localStorage immediately so it's kept in sync
                if (window.editInvoiceData === null) {
                    localStorage.setItem('fintrix_rep_pos_cart', JSON.stringify(cart));
                }

                updateCartUI();
                prodModal.hide();
                
                prodSearchInput.value = '';
                prodSearchInput.dispatchEvent(new Event('input'));
            });

            // --- Process Final Sale ---
            document.getElementById('btnConfirmSale').addEventListener('click', function() {
                if (cart.length === 0) return;

                const chequeAmt = parseFloat(payCheque.value) || 0;
                if (chequeAmt > 0) {
                    if(!document.getElementById('chkBank').value || !document.getElementById('chkNum').value || !document.getElementById('chkDate').value) {
                        alert("Please fill in all Cheque details (Bank, Number, Date).");
                        return;
                    }
                }

                const originalBtn = this.innerHTML;
                this.disabled = true;
                this.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Locating & Processing...';
                const msgBox = document.getElementById('checkoutMessage');
                msgBox.innerHTML = '';

                let lat = null, lng = null;

                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(
                        function(position) {
                            lat = position.coords.latitude;
                            lng = position.coords.longitude;
                            sendCheckoutRequest(lat, lng, originalBtn, msgBox);
                        }, 
                        function(error) {
                            console.warn("Location error:", error.message);
                            sendCheckoutRequest(null, null, originalBtn, msgBox);
                        }, 
                        { enableHighAccuracy: true, timeout: 5000 }
                    );
                } else {
                    sendCheckoutRequest(null, null, originalBtn, msgBox);
                }
            });

            async function sendCheckoutRequest(lat, lng, originalBtn, msgBox) {
                const finalCart = cart.map(item => {
                    const gross = item.sell_price * item.quantity;
                    let itemDisAmt = item.dis_type === '%' ? (gross * (item.dis_value / 100)) : (item.dis_value * item.quantity);
                    return {
                        product_id: item.product_id,
                        supplier_id: item.supplier_id,
                        sell_price: item.sell_price,
                        quantity: item.quantity,
                        discount: itemDisAmt,
                        is_foc: item.is_foc ? 1 : 0,
                        promo_id: item.promo_id || null 
                    };
                });

                const payload = {
                    edit_order_id: window.editInvoiceData ? window.editInvoiceData.order_id : null,
                    assignment_id: <?php echo $assignment_id ? $assignment_id : 'null'; ?>,
                    customer_id: selectedCustomerData.id,
                    bill_discount: window.absoluteBillDiscount || 0,
                    tax_amount: window.absoluteTaxAmount || 0,
                    paid_cash: parseFloat(payCash.value) || 0,
                    paid_bank: parseFloat(payBank.value) || 0,
                    paid_cheque: parseFloat(payCheque.value) || 0,
                    cheque_bank: document.getElementById('chkBank').value,
                    cheque_number: document.getElementById('chkNum').value,
                    cheque_date: document.getElementById('chkDate').value,
                    latitude: lat,
                    longitude: lng,
                    cart: finalCart
                };

                try {
                    const response = await fetch('../ajax/process_checkout.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(payload)
                    });
                    
                    const rawText = await response.text();
                    
                    let result;
                    try {
                        result = JSON.parse(rawText);
                    } catch(e) {
                        console.error("Server Outputted Non-JSON:", rawText);
                        msgBox.innerHTML = `<div class="alert alert-danger p-2">Server Error. Check console logs.</div>`;
                        document.getElementById('btnConfirmSale').disabled = false;
                        document.getElementById('btnConfirmSale').innerHTML = originalBtn;
                        return;
                    }

                    if (result.success) {
                        const bsOffcanvas = bootstrap.Offcanvas.getInstance(document.getElementById('checkoutCanvas'));
                        if(bsOffcanvas) bsOffcanvas.hide();

                        // Clear Catalog local storage since checkout was successful
                        localStorage.removeItem('fintrix_rep_pos_cart');

                        finalOrderId = result.order_id;
                        document.getElementById('successOrderId').textContent = '#' + String(finalOrderId).padStart(6, '0');
                        
                        // Handle Email Button Visibility
                        const btnEmail = document.getElementById('btnEmailReceipt');
                        if (selectedCustomerData.email && selectedCustomerData.email !== '') {
                            btnEmail.style.display = 'block';
                            btnEmail.innerHTML = '<i class="bi bi-envelope"></i> Email Receipt';
                            btnEmail.disabled = false;
                            btnEmail.classList.remove('btn-primary');
                            btnEmail.classList.add('btn-outline-primary');
                        } else {
                            btnEmail.style.display = 'none';
                        }

                        new bootstrap.Modal(document.getElementById('successModal')).show();
                    } else {
                        msgBox.innerHTML = `<div class="alert alert-danger p-2">${result.message}</div>`;
                        document.getElementById('btnConfirmSale').disabled = false;
                        document.getElementById('btnConfirmSale').innerHTML = originalBtn;
                    }
                } catch (error) {
                    console.error("Fetch Error:", error);
                    msgBox.innerHTML = `<div class="alert alert-danger p-2">Network Error. Check connection.</div>`;
                    document.getElementById('btnConfirmSale').disabled = false;
                    document.getElementById('btnConfirmSale').innerHTML = originalBtn;
                }
            }

            // Success Modal Logic
            document.getElementById('btnPrintInvoice').addEventListener('click', function() {
                if(finalOrderId) window.open(`../pages/view_invoice.php?id=${finalOrderId}`, '_blank');
            });

            document.getElementById('btnShowQR').addEventListener('click', function() {
                if(finalOrderId) {
                    const container = document.getElementById('qrContainer');
                    const qrcodeEl = document.getElementById('qrcode');
                    
                    qrcodeEl.innerHTML = ''; 
                    const invoiceUrl = window.location.origin + window.location.pathname.replace('/rep/create_order.php', '') + `/pages/view_invoice.php?id=${finalOrderId}`;
                    
                    new QRCode(qrcodeEl, {
                        text: invoiceUrl,
                        width: 200,
                        height: 200,
                        colorDark : "#000000",
                        colorLight : "#ffffff",
                        correctLevel : QRCode.CorrectLevel.H
                    });
                    
                    container.classList.remove('d-none');
                    this.classList.add('d-none'); 
                }
            });

            // Email Receipt Logic
            document.getElementById('btnEmailReceipt').addEventListener('click', async function() {
                if(!finalOrderId) return;
                const btn = this;
                const originalHtml = btn.innerHTML;
                btn.disabled = true;
                btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Sending...';

                try {
                    const response = await fetch('../ajax/send_receipt.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: `order_id=${finalOrderId}`
                    });
                    const result = await response.json();
                    
                    if(result.success) {
                        btn.innerHTML = '<i class="bi bi-check-circle"></i> Sent!';
                        btn.classList.replace('btn-outline-primary', 'btn-primary');
                    } else {
                        alert('Error: ' + result.error);
                        btn.disabled = false;
                        btn.innerHTML = originalHtml;
                    }
                } catch(e) {
                    alert('Network or Server Error.');
                    btn.disabled = false;
                    btn.innerHTML = originalHtml;
                }
            });

            // --- 5. INITIALIZATION (Edit Mode & Auto-Select) ---
            if (window.editInvoiceData !== null) {
                const data = window.editInvoiceData;
                cart = data.cart;
                billDisType.value = 'Rs';
                billDisValue.value = data.bill_discount;
                taxDisType.value = 'Rs';
                taxDisValue.value = data.tax_amount;

                payCash.value = data.paid_cash > 0 ? data.paid_cash : '';
                payBank.value = data.paid_bank > 0 ? data.paid_bank : '';
                payCheque.value = data.paid_cheque > 0 ? data.paid_cheque : '';

                if (data.paid_cheque > 0 && data.cheque) {
                    document.getElementById('chkBank').value = data.cheque.bank;
                    document.getElementById('chkNum').value = data.cheque.number;
                    document.getElementById('chkDate').value = data.cheque.date;
                    chequeFields.classList.remove('d-none');
                }
                
                const custIdToSelect = data.customer_id ? data.customer_id : 0;
                const custs = <?php echo json_encode($my_customers); ?>;
                const c = custs.find(x => x.id == custIdToSelect);
                if(c) {
                    selectCustomer(c.id, c.name, c.address, c.outstanding, c.email);
                } else {
                    selectCustomer(null, 'Walk-in Customer', '', 0, '');
                }
            } else {
                
                // Normal Mode - Check if there is an existing cart from Catalog
                const savedCart = localStorage.getItem('fintrix_rep_pos_cart');
                if (savedCart) {
                    try {
                        cart = JSON.parse(savedCart);
                    } catch(e) {}
                }

                const autoCustId = '<?php echo $auto_select_customer; ?>';
                if(autoCustId !== '') {
                    if (autoCustId === '0') {
                        selectCustomer(null, 'Walk-in Customer', '', 0, '');
                    } else {
                        const custs = <?php echo json_encode($my_customers); ?>;
                        const c = custs.find(x => x.id == autoCustId);
                        if(c) {
                            selectCustomer(c.id, c.name, c.address, c.outstanding, c.email);
                        } else {
                            navBackBtn.href = "dashboard.php";
                        }
                    }
                } else {
                    navBackBtn.href = "dashboard.php";
                    updateCartUI();
                }
            }
        });
        </script>
    <?php else: ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php endif; ?>

</body>
</html>