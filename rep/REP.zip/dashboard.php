<?php
// Enable error reporting for easier debugging of 500 errors
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/db.php';
require_once '../includes/auth_check.php';
requireRole(['rep']); // Strictly for Sales Reps

$rep_id = $_SESSION['user_id'];

// --- AUTO DB MIGRATION FOR ROUTES & EXPENSES ---
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS routes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS rep_routes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        rep_id INT NOT NULL,
        driver_id INT NULL,
        route_id INT NOT NULL,
        assign_date DATE NOT NULL,
        status ENUM('assigned', 'accepted', 'rejected', 'completed', 'unloaded') DEFAULT 'assigned',
        start_meter DECIMAL(8,1) NULL,
        end_meter DECIMAL(8,1) NULL,
        expected_cash DECIMAL(12,2) NULL,
        actual_cash DECIMAL(12,2) NULL,
        expected_bank DECIMAL(12,2) NULL,
        actual_bank DECIMAL(12,2) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (rep_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE CASCADE,
        FOREIGN KEY (driver_id) REFERENCES employees(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS route_loads (
        id INT AUTO_INCREMENT PRIMARY KEY,
        assignment_id INT NOT NULL,
        product_id INT NOT NULL,
        loaded_qty INT NOT NULL,
        returned_qty INT NULL,
        short_qty INT NULL,
        FOREIGN KEY (assignment_id) REFERENCES rep_routes(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS route_expenses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        assignment_id INT NOT NULL,
        type VARCHAR(50) NOT NULL,
        amount DECIMAL(12,2) NOT NULL,
        description VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (assignment_id) REFERENCES rep_routes(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    try {
        $pdo->query("SELECT user_id FROM rep_daily_sessions LIMIT 1");
    } catch (PDOException $e) {
        $pdo->exec("DROP TABLE IF EXISTS rep_daily_sessions");
        $pdo->exec("CREATE TABLE rep_daily_sessions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            session_date DATE NOT NULL,
            start_time DATETIME NULL,
            end_time DATETIME NULL,
            status ENUM('active', 'ended') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY(user_id, session_date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS rep_location_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        latitude DECIMAL(10,8) NOT NULL,
        longitude DECIMAL(11,8) NOT NULL,
        activity_type VARCHAR(50) NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

} catch(PDOException $e) { /* Ignored if already exists */ }

try {
    $pdo->exec("ALTER TABLE rep_routes DROP INDEX rep_date");
} catch(PDOException $e) {}
// ------------------------------------

// --- Handle Post Actions for Routes & Starting/Ending Day ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['route_action'])) {
    $action = $_POST['route_action'];
    $assignment_id = (int)$_POST['assignment_id'];

    if ($action == 'accept') {
        $pdo->prepare("UPDATE rep_routes SET status = 'accepted' WHERE id = ? AND rep_id = ?")->execute([$assignment_id, $rep_id]);
    } elseif ($action == 'reject') {
        $pdo->prepare("UPDATE rep_routes SET status = 'rejected' WHERE id = ? AND rep_id = ?")->execute([$assignment_id, $rep_id]);
    } elseif ($action == 'start_day') {
        $meter = (float)$_POST['start_meter'];
        $driver_id = !empty($_POST['driver_id']) ? (int)$_POST['driver_id'] : null;
        $lat = !empty($_POST['latitude']) ? (float)$_POST['latitude'] : null;
        $lng = !empty($_POST['longitude']) ? (float)$_POST['longitude'] : null;

        $pdo->prepare("UPDATE rep_routes SET start_meter = ? WHERE id = ? AND rep_id = ?")->execute([$meter, $assignment_id, $rep_id]);
        $pdo->prepare("INSERT INTO rep_daily_sessions (user_id, session_date, start_time, status) VALUES (?, CURDATE(), NOW(), 'active') ON DUPLICATE KEY UPDATE start_time = NOW(), status = 'active'")->execute([$rep_id]);
        
        if ($lat && $lng) {
            $pdo->prepare("INSERT INTO rep_location_logs (user_id, latitude, longitude, activity_type, timestamp) VALUES (?, ?, ?, 'day_started', NOW())")->execute([$rep_id, $lat, $lng]);
        }

        if ($driver_id) {
            $pdo->prepare("INSERT INTO attendance (employee_id, work_date, status) VALUES (?, CURDATE(), 'present') ON DUPLICATE KEY UPDATE status = 'present'")->execute([$driver_id]);
        }

        $empStmt = $pdo->prepare("SELECT id FROM employees WHERE user_id = ? OR (name = ? AND designation = 'Sales Rep') LIMIT 1");
        $empStmt->execute([$rep_id, $_SESSION['user_name']]);
        $rep_emp_id = $empStmt->fetchColumn();

        if (!$rep_emp_id) {
            $empCode = 'REP-' . str_pad($rep_id, 3, '0', STR_PAD_LEFT);
            $pdo->prepare("INSERT INTO employees (user_id, emp_code, name, designation, daily_rate, status) VALUES (?, ?, ?, 'Sales Rep', 0.00, 'active')")->execute([$rep_id, $empCode, $_SESSION['user_name']]);
            $rep_emp_id = $pdo->lastInsertId();
        }

        if ($rep_emp_id) {
            $pdo->prepare("INSERT INTO attendance (employee_id, work_date, status) VALUES (?, CURDATE(), 'present') ON DUPLICATE KEY UPDATE status = 'present'")->execute([$rep_emp_id]);
        }
    } elseif ($action == 'add_expense') {
        $type = $_POST['expense_type'];
        $amount = (float)$_POST['expense_amount'];
        $desc = trim($_POST['expense_desc']);
        $pdo->prepare("INSERT INTO route_expenses (assignment_id, type, amount, description) VALUES (?, ?, ?, ?)")->execute([$assignment_id, $type, $amount, $desc]);
    } elseif ($action == 'delete_expense') {
        $expense_id = (int)$_POST['expense_id'];
        $pdo->prepare("DELETE FROM route_expenses WHERE id = ? AND assignment_id = ?")->execute([$expense_id, $assignment_id]);
    } elseif ($action == 'end_day') {
        $end_meter = (float)$_POST['end_meter'];
        $actual_cash = (float)($_POST['actual_cash_total_input'] ?? 0);
        $expected_cash = (float)($_POST['expected_cash_val'] ?? 0);
        $lat = !empty($_POST['latitude']) ? (float)$_POST['latitude'] : null;
        $lng = !empty($_POST['longitude']) ? (float)$_POST['longitude'] : null;
        
        $pdo->prepare("UPDATE rep_routes SET end_meter = ?, actual_cash = ?, expected_cash = ?, status = 'completed' WHERE id = ? AND rep_id = ?")->execute([$end_meter, $actual_cash, $expected_cash, $assignment_id, $rep_id]);
        $pdo->prepare("UPDATE rep_daily_sessions SET end_time = NOW(), status = 'ended' WHERE user_id = ? AND session_date = CURDATE()")->execute([$rep_id]);
        
        if ($lat && $lng) {
            $pdo->prepare("INSERT INTO rep_location_logs (user_id, latitude, longitude, activity_type, timestamp) VALUES (?, ?, ?, 'day_ended', NOW())")->execute([$rep_id, $lat, $lng]);
        }
    }
    header("Location: dashboard.php");
    exit;
}

// --- Fetch Key Metrics ---
$route_expenses = [];
$total_expenses = 0;
$cash_sales = 0;
$collected_cheques = [];

try {
    $routeStmt = $pdo->prepare("
        SELECT rr.*, r.name as route_name, r.description, e.name as driver_name 
        FROM rep_routes rr 
        JOIN routes r ON rr.route_id = r.id 
        LEFT JOIN employees e ON rr.driver_id = e.id
        WHERE rr.rep_id = ? AND rr.assign_date = CURDATE()
        ORDER BY rr.id DESC LIMIT 1
    ");
    $routeStmt->execute([$rep_id]);
    $todays_route = $routeStmt->fetch();

    $assignment_id = $todays_route ? $todays_route['id'] : null;

    if ($assignment_id) {
        $stmt = $pdo->prepare("SELECT SUM(total_amount) FROM orders WHERE assignment_id = ?");
        $stmt->execute([$assignment_id]);
        $today_sales = $stmt->fetchColumn() ?: 0;

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE assignment_id = ?");
        $stmt->execute([$assignment_id]);
        $today_bills = $stmt->fetchColumn() ?: 0;
        
        $stmt = $pdo->prepare("SELECT SUM(paid_cash) FROM orders WHERE assignment_id = ?");
        $stmt->execute([$assignment_id]);
        $cash_sales = (float)$stmt->fetchColumn() ?: 0;

        $stmt = $pdo->prepare("SELECT * FROM route_expenses WHERE assignment_id = ? ORDER BY created_at DESC");
        $stmt->execute([$assignment_id]);
        $route_expenses = $stmt->fetchAll();
        foreach($route_expenses as $exp) { $total_expenses += $exp['amount']; }
        
        $stmt = $pdo->prepare("
            SELECT ch.bank_name, ch.amount 
            FROM cheques ch JOIN orders o ON ch.order_id = o.id 
            WHERE o.assignment_id = ? AND ch.type = 'incoming'
        ");
        $stmt->execute([$assignment_id]);
        $collected_cheques = $stmt->fetchAll();
    } else {
        $stmt = $pdo->prepare("SELECT SUM(total_amount) FROM orders WHERE rep_id = ? AND DATE(created_at) = CURDATE()");
        $stmt->execute([$rep_id]);
        $today_sales = $stmt->fetchColumn() ?: 0;

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE rep_id = ? AND DATE(created_at) = CURDATE()");
        $stmt->execute([$rep_id]);
        $today_bills = $stmt->fetchColumn() ?: 0;
    }

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE rep_id = ? AND payment_status != 'paid'");
    $stmt->execute([$rep_id]);
    $pending_orders = $stmt->fetchColumn() ?: 0;

    $load_manifest = [];
    if ($assignment_id) {
        $loadStmt = $pdo->prepare("
            SELECT rl.loaded_qty, p.name, p.sku 
            FROM route_loads rl 
            JOIN products p ON rl.product_id = p.id 
            WHERE rl.assignment_id = ?
        ");
        $loadStmt->execute([$assignment_id]);
        $load_manifest = $loadStmt->fetchAll();
    }

} catch(PDOException $e) {
    die("<div style='padding: 20px; color: red;'>Database Error: " . htmlspecialchars($e->getMessage()) . "</div>");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Rep App — Fintrix</title>
    
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#0f0f0f">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="Fintrix Rep">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        :root {
            --bg: #f7f7f5;
            --surface: #ffffff;
            --surface-2: #f0efec;
            --border: #e4e2dd;
            --border-strong: #ccc9c2;
            --text-primary: #111110;
            --text-secondary: #78746c;
            --text-tertiary: #a8a49c;
            --accent: #e8650a;
            --accent-light: #fef0e7;
            --accent-dim: rgba(232,101,10,0.12);
            --green: #1a7a4a;
            --green-light: #e8f5ee;
            --red: #c0392b;
            --red-light: #fcecea;
            --blue: #1a5ca8;
            --blue-light: #e8f0fb;
            --radius: 14px;
            --radius-sm: 8px;
            --shadow: 0 1px 3px rgba(0,0,0,0.06), 0 4px 12px rgba(0,0,0,0.04);
            --shadow-md: 0 2px 8px rgba(0,0,0,0.08), 0 8px 24px rgba(0,0,0,0.06);
            --nav-h: 68px;
        }

        * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }

        body {
            background: var(--bg);
            font-family: 'DM Sans', sans-serif;
            color: var(--text-primary);
            padding-bottom: calc(var(--nav-h) + 16px);
            -webkit-font-smoothing: antialiased;
            margin: 0;
        }

        /* ── Header ── */
        .app-header {
            background: var(--text-primary);
            padding: 52px 20px 24px;
            position: relative;
            overflow: hidden;
        }
        .app-header::after {
            content: '';
            position: absolute;
            top: -60px; right: -40px;
            width: 180px; height: 180px;
            border-radius: 50%;
            background: rgba(232,101,10,0.15);
            pointer-events: none;
        }
        .header-label {
            font-size: 10px;
            font-weight: 600;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            color: rgba(255,255,255,0.4);
            margin-bottom: 4px;
        }
        .header-name {
            font-size: 22px;
            font-weight: 700;
            color: #fff;
            margin: 0;
            line-height: 1.2;
        }
        .header-date {
            font-size: 11px;
            color: rgba(255,255,255,0.35);
            font-family: 'DM Mono', monospace;
            margin-top: 4px;
        }
        .header-actions {
            display: flex;
            gap: 8px;
            align-items: center;
        }
        .btn-install {
            background: var(--accent);
            color: #fff;
            border: none;
            border-radius: 20px;
            padding: 6px 14px;
            font-size: 12px;
            font-weight: 600;
            font-family: 'DM Sans', sans-serif;
            cursor: pointer;
        }
        .btn-logout {
            width: 36px; height: 36px;
            border-radius: 50%;
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.12);
            display: flex; align-items: center; justify-content: center;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            font-size: 16px;
            transition: background 0.15s;
        }
        .btn-logout:hover { background: rgba(255,255,255,0.18); color: #fff; }

        /* ── Page Content ── */
        .page-content {
            padding: 20px 16px 0;
        }

        /* ── Stats Row ── */
        .stats-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 20px;
        }
        .stat-tile {
            background: var(--surface);
            border-radius: var(--radius);
            padding: 16px;
            border: 1px solid var(--border);
        }
        .stat-tile .stat-label {
            font-size: 10px;
            font-weight: 600;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: var(--text-tertiary);
            margin-bottom: 8px;
        }
        .stat-tile .stat-value {
            font-size: 22px;
            font-weight: 700;
            color: var(--text-primary);
            line-height: 1;
            font-family: 'DM Mono', monospace;
        }
        .stat-tile .stat-value.small-val {
            font-size: 18px;
        }
        .stat-tile .stat-sub {
            font-size: 11px;
            color: var(--text-tertiary);
            margin-top: 4px;
        }

        /* ── Section Title ── */
        .section-title {
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            color: var(--text-tertiary);
            margin: 24px 0 10px;
            padding: 0 2px;
        }

        /* ── Route Card ── */
        .route-card {
            background: var(--surface);
            border-radius: var(--radius);
            border: 1px solid var(--border);
            overflow: hidden;
            margin-bottom: 16px;
        }
        .route-card-header {
            padding: 14px 16px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid var(--border);
        }
        .route-card-body { padding: 16px; }
        .status-dot {
            width: 8px; height: 8px;
            border-radius: 50%;
            flex-shrink: 0;
        }
        .status-dot.pending { background: #d4a017; box-shadow: 0 0 0 3px rgba(212,160,23,0.2); }
        .status-dot.active { background: var(--green); box-shadow: 0 0 0 3px rgba(26,122,74,0.2); }
        .status-dot.completed { background: var(--blue); box-shadow: 0 0 0 3px rgba(26,92,168,0.2); }
        .status-dot.rejected { background: var(--red); box-shadow: 0 0 0 3px rgba(192,57,43,0.2); }
        .status-label {
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.08em;
            text-transform: uppercase;
        }
        .route-name {
            font-size: 16px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 4px;
        }
        .route-meta {
            font-size: 12px;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .route-meta .dot { opacity: 0.3; }

        /* Manifest list */
        .manifest-box {
            background: var(--surface-2);
            border-radius: var(--radius-sm);
            padding: 12px;
            margin-bottom: 14px;
            border: 1px solid var(--border);
        }
        .manifest-box .manifest-title {
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            color: var(--text-tertiary);
            margin-bottom: 8px;
        }
        .manifest-item {
            font-size: 13px;
            color: var(--text-primary);
            padding: 3px 0;
            display: flex;
            gap: 8px;
        }
        .manifest-qty { font-family: 'DM Mono', monospace; color: var(--green); font-weight: 600; min-width: 30px; }

        /* Action buttons in route card */
        .route-btn-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
        }
        .btn-route {
            border-radius: var(--radius-sm);
            padding: 12px;
            font-size: 13px;
            font-weight: 600;
            font-family: 'DM Sans', sans-serif;
            border: none;
            cursor: pointer;
            width: 100%;
            transition: opacity 0.15s, transform 0.1s;
        }
        .btn-route:active { opacity: 0.8; transform: scale(0.98); }
        .btn-route.accept { background: var(--green); color: #fff; }
        .btn-route.reject { background: var(--surface-2); color: var(--red); border: 1px solid rgba(192,57,43,0.25); }
        .btn-route.primary { background: var(--text-primary); color: #fff; }
        .btn-route.danger { background: var(--red); color: #fff; }

        /* Meter input */
        .meter-wrap { margin-bottom: 14px; }
        .meter-label {
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            color: var(--text-tertiary);
            margin-bottom: 6px;
        }
        .meter-input {
            width: 100%;
            background: var(--surface-2);
            border: 1.5px solid var(--border);
            border-radius: var(--radius-sm);
            padding: 12px 14px;
            font-size: 20px;
            font-family: 'DM Mono', monospace;
            font-weight: 500;
            color: var(--text-primary);
            outline: none;
            transition: border-color 0.15s;
        }
        .meter-input:focus { border-color: var(--accent); }

        /* Active meter badge */
        .meter-badge {
            font-family: 'DM Mono', monospace;
            font-size: 12px;
            background: var(--surface-2);
            border: 1px solid var(--border);
            border-radius: 6px;
            padding: 3px 8px;
            color: var(--text-secondary);
        }

        /* Summary rows */
        .summary-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 9px 0;
            border-bottom: 1px solid var(--border);
            font-size: 13px;
        }
        .summary-row:last-child { border-bottom: none; }
        .summary-row .s-label { color: var(--text-secondary); }
        .summary-row .s-value { font-weight: 600; font-family: 'DM Mono', monospace; }
        .summary-row.highlight .s-label { font-weight: 700; color: var(--text-primary); }
        .summary-row.highlight .s-value { font-size: 20px; color: var(--blue); }

        /* No route notice */
        .no-route-notice {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 16px;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 16px;
        }
        .no-route-icon {
            width: 36px; height: 36px;
            background: var(--surface-2);
            border-radius: 8px;
            display: flex; align-items: center; justify-content: center;
            flex-shrink: 0;
            font-size: 16px;
            color: var(--text-tertiary);
        }
        .no-route-text { font-size: 13px; color: var(--text-secondary); line-height: 1.5; }

        /* ── Menu Items ── */
        .menu-item {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 14px 16px;
            display: flex;
            align-items: center;
            gap: 14px;
            text-decoration: none;
            color: var(--text-primary);
            margin-bottom: 8px;
            transition: background 0.1s, transform 0.1s;
        }
        .menu-item:active { background: var(--surface-2); transform: scale(0.99); }
        .menu-icon {
            width: 40px; height: 40px;
            border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 17px;
            flex-shrink: 0;
        }
        .menu-text { flex: 1; }
        .menu-title { font-size: 14px; font-weight: 600; margin-bottom: 2px; }
        .menu-sub { font-size: 11px; color: var(--text-tertiary); }
        .menu-chevron { font-size: 12px; color: var(--text-tertiary); }

        /* Icon color variants */
        .ic-green { background: var(--green-light); color: var(--green); }
        .ic-blue  { background: var(--blue-light);  color: var(--blue);  }
        .ic-red   { background: var(--red-light);   color: var(--red);   }
        .ic-amber { background: #fef3e2; color: #b45309; }
        .ic-mono  { background: var(--surface-2); color: var(--text-secondary); }
        .ic-accent { background: var(--accent-light); color: var(--accent); }

        /* ── Warning Banner ── */
        .warn-banner {
            background: #fffbeb;
            border: 1px solid #fde68a;
            border-radius: var(--radius);
            padding: 14px 16px;
            display: flex;
            align-items: center;
            gap: 12px;
            margin-top: 16px;
        }
        .warn-icon { font-size: 18px; color: #d97706; flex-shrink: 0; }
        .warn-title { font-size: 13px; font-weight: 700; color: var(--text-primary); margin-bottom: 2px; }
        .warn-sub { font-size: 12px; color: var(--text-secondary); }

        /* ── Bottom Nav ── */
        .bottom-nav {
            position: fixed;
            bottom: 0; left: 0; right: 0;
            background: var(--surface);
            border-top: 1px solid var(--border);
            display: flex;
            justify-content: space-around;
            align-items: center;
            height: var(--nav-h);
            z-index: 1000;
            padding-bottom: env(safe-area-inset-bottom, 0);
        }
        .nav-tab {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            text-decoration: none;
            color: var(--text-tertiary);
            font-size: 10px;
            font-weight: 500;
            letter-spacing: 0.04em;
            padding: 8px 0;
            transition: color 0.15s;
        }
        .nav-tab i { font-size: 20px; }
        .nav-tab.active { color: var(--text-primary); }
        .nav-tab.active i { color: var(--accent); }
        .nav-fab {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            text-decoration: none;
        }
        .fab-circle {
            width: 46px; height: 46px;
            border-radius: 50%;
            background: var(--text-primary);
            display: flex; align-items: center; justify-content: center;
            font-size: 20px;
            color: #fff;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            margin-top: -16px;
        }
        .fab-label { font-size: 10px; color: var(--text-secondary); font-weight: 600; margin-top: -2px; }

        /* ── Modal Styles ── */
        .modal-content {
            border: none;
            border-radius: 20px 20px 0 0;
            box-shadow: 0 -8px 40px rgba(0,0,0,0.12);
            font-family: 'DM Sans', sans-serif;
        }
        .modal.fade .modal-dialog { transform: translateY(100px); }
        .modal.show .modal-dialog { transform: translateY(0); }
        .modal-dialog { margin: 0; position: fixed; bottom: 0; left: 0; right: 0; max-width: 100%; }
        .modal-header {
            padding: 16px 20px 12px;
            border-bottom: 1px solid var(--border);
        }
        .modal-title { font-size: 16px; font-weight: 700; }
        .modal-body { padding: 16px 20px 32px; max-height: 82vh; overflow-y: auto; }

        .form-label-sm {
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            color: var(--text-tertiary);
            margin-bottom: 6px;
            display: block;
        }
        .form-ctrl {
            width: 100%;
            background: var(--surface-2);
            border: 1.5px solid var(--border);
            border-radius: var(--radius-sm);
            padding: 11px 13px;
            font-size: 14px;
            font-family: 'DM Sans', sans-serif;
            color: var(--text-primary);
            outline: none;
            transition: border-color 0.15s;
            appearance: none;
            -webkit-appearance: none;
        }
        .form-ctrl:focus { border-color: var(--accent); }

        .expense-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid var(--border);
        }
        .expense-item:last-child { border-bottom: none; }
        .expense-item-name { font-size: 13px; font-weight: 600; }
        .expense-item-desc { font-size: 11px; color: var(--text-tertiary); }
        .expense-item-amount { font-family: 'DM Mono', monospace; font-size: 13px; font-weight: 600; color: var(--red); }
        .btn-del { background: none; border: none; color: var(--text-tertiary); padding: 0 4px; font-size: 15px; cursor: pointer; }

        /* Denom table */
        .denom-row {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 8px;
        }
        .denom-label {
            font-family: 'DM Mono', monospace;
            font-size: 13px;
            color: var(--text-secondary);
            width: 58px;
            text-align: right;
            flex-shrink: 0;
        }
        .denom-input {
            flex: 1;
            background: var(--surface-2);
            border: 1.5px solid var(--border);
            border-radius: var(--radius-sm);
            padding: 9px 10px;
            font-family: 'DM Mono', monospace;
            font-size: 15px;
            text-align: center;
            color: var(--text-primary);
            outline: none;
        }
        .denom-input:focus { border-color: var(--accent); }

        .cash-summary-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 0;
        }
        .cash-summary-row .cs-label { font-size: 12px; color: var(--text-secondary); font-weight: 500; }
        .cash-summary-row .cs-val { font-family: 'DM Mono', monospace; font-size: 16px; font-weight: 700; }

        .btn-full {
            width: 100%;
            border: none;
            border-radius: var(--radius-sm);
            padding: 14px;
            font-size: 14px;
            font-weight: 700;
            font-family: 'DM Sans', sans-serif;
            cursor: pointer;
            transition: opacity 0.15s, transform 0.1s;
            letter-spacing: 0.02em;
        }
        .btn-full:active { opacity: 0.85; transform: scale(0.99); }
        .btn-full.dark { background: var(--text-primary); color: #fff; }
        .btn-full.red { background: var(--red); color: #fff; }
        .btn-full.outline { background: transparent; border: 1.5px solid var(--border); color: var(--text-primary); }

        .divider { height: 1px; background: var(--border); margin: 14px 0; }
        .tag { display: inline-flex; align-items: center; gap: 4px; font-size: 11px; font-weight: 600; padding: 3px 8px; border-radius: 20px; }
        .tag.verified { background: var(--green-light); color: var(--green); }
        .tag.amber { background: #fef3e2; color: #b45309; }
    </style>
</head>
<body>

    <!-- ── Header ── -->
    <div class="app-header">
        <div class="d-flex justify-content-between align-items-start">
            <div>
                <div class="header-label">Sales Rep</div>
                <h1 class="header-name"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h1>
                <div class="header-date"><?php echo date('l, d M Y'); ?></div>
            </div>
            <div class="header-actions">
                <button id="installAppBtn" class="btn-install d-none" onclick="installApp()">
                    <i class="bi bi-download"></i> Install
                </button>
                <a href="../logout.php" class="btn-logout">
                    <i class="bi bi-power"></i>
                </a>
            </div>
        </div>
    </div>

    <div class="page-content">

        <!-- ── Stats ── -->
        <div class="stats-row" style="margin-top: 20px;">
            <div class="stat-tile">
                <div class="stat-label">Route Sales</div>
                <div class="stat-value <?php echo $today_sales >= 100000 ? 'small-val' : ''; ?>">
                    <?php echo $today_sales >= 1000 ? 'Rs ' . number_format($today_sales / 1000, 1) . 'k' : 'Rs ' . number_format($today_sales); ?>
                </div>
                <div class="stat-sub">Today</div>
            </div>
            <div class="stat-tile">
                <div class="stat-label">Bills Issued</div>
                <div class="stat-value"><?php echo $today_bills; ?></div>
                <div class="stat-sub">Active route</div>
            </div>
        </div>

        <!-- ── Route Section ── -->
        <?php if ($todays_route): ?>

            <!-- State 1: Assigned -->
            <?php if ($todays_route['status'] == 'assigned'): ?>
            <div class="route-card">
                <div class="route-card-header">
                    <span class="status-dot pending"></span>
                    <span class="status-label" style="color: #d4a017;">Awaiting Confirmation</span>
                </div>
                <div class="route-card-body">
                    <div class="route-name"><?php echo htmlspecialchars($todays_route['route_name']); ?></div>
                    <div class="route-meta">
                        <i class="bi bi-person-fill" style="font-size:11px;"></i>
                        <?php echo htmlspecialchars($todays_route['driver_name'] ?: 'Self-Driven'); ?>
                        <?php if(!empty($todays_route['description'])): ?>
                            <span class="dot">·</span>
                            <span><?php echo htmlspecialchars($todays_route['description']); ?></span>
                        <?php endif; ?>
                    </div>

                    <?php if(!empty($load_manifest)): ?>
                    <div class="manifest-box" style="margin-top:14px;">
                        <div class="manifest-title">Load Manifest — Verify</div>
                        <div style="max-height:100px;overflow-y:auto;">
                            <?php foreach($load_manifest as $m): ?>
                            <div class="manifest-item">
                                <span class="manifest-qty"><?php echo $m['loaded_qty']; ?>×</span>
                                <span><?php echo htmlspecialchars($m['name']); ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="route-btn-row" style="margin-top:14px;">
                        <form method="POST">
                            <input type="hidden" name="route_action" value="reject">
                            <input type="hidden" name="assignment_id" value="<?php echo $todays_route['id']; ?>">
                            <button type="submit" class="btn-route reject">Reject Load</button>
                        </form>
                        <form method="POST">
                            <input type="hidden" name="route_action" value="accept">
                            <input type="hidden" name="assignment_id" value="<?php echo $todays_route['id']; ?>">
                            <button type="submit" class="btn-route accept">Accept Route</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- State 2: Accepted, needs start meter -->
            <?php elseif ($todays_route['status'] == 'accepted' && is_null($todays_route['start_meter'])): ?>
            <div class="route-card">
                <div class="route-card-header">
                    <span class="status-dot active"></span>
                    <span class="status-label" style="color: var(--green);">Accepted — Ready to Start</span>
                </div>
                <div class="route-card-body">
                    <div class="route-name"><?php echo htmlspecialchars($todays_route['route_name']); ?></div>
                    <div class="route-meta" style="margin-bottom:16px;">
                        <i class="bi bi-person-fill" style="font-size:11px;"></i>
                        <?php echo htmlspecialchars($todays_route['driver_name'] ?: 'Self'); ?>
                    </div>
                    
                    <form method="POST" id="startDayForm">
                        <input type="hidden" name="route_action" value="start_day">
                        <input type="hidden" name="assignment_id" value="<?php echo $todays_route['id']; ?>">
                        <input type="hidden" name="driver_id" value="<?php echo $todays_route['driver_id']; ?>">
                        <input type="hidden" name="latitude" id="start_lat" value="">
                        <input type="hidden" name="longitude" id="start_lng" value="">
                        
                        <div class="meter-wrap">
                            <div class="meter-label">Vehicle Start Meter (km)</div>
                            <input type="text" inputmode="numeric" name="start_meter" class="meter-input" required placeholder="45200.5">
                        </div>
                        <button type="button" class="btn-full dark" onclick="processStartDay(this);">Start Day</button>
                    </form>
                </div>
            </div>

            <!-- State 3: Active day in progress -->
            <?php elseif ($todays_route['status'] == 'accepted' && !is_null($todays_route['start_meter'])): ?>
            <div class="route-card">
                <div class="route-card-header" style="justify-content: space-between;">
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span class="status-dot active"></span>
                        <span class="status-label" style="color: var(--green);">Route Active</span>
                    </div>
                    <span class="meter-badge">Start: <?php echo number_format($todays_route['start_meter'], 1); ?></span>
                </div>
                <div class="route-card-body">
                    <div class="route-name" style="margin-bottom:14px;"><?php echo htmlspecialchars($todays_route['route_name']); ?></div>
                    <button type="button" class="btn-full red" data-bs-toggle="modal" data-bs-target="#endDayModal">
                        <i class="bi bi-stop-circle" style="margin-right:6px;"></i>End Route &amp; Day
                    </button>
                </div>
            </div>

            <!-- State 4 & 5: Completed / Unloaded -->
            <?php elseif (in_array($todays_route['status'], ['completed', 'unloaded'])): ?>
            <div class="route-card">
                <div class="route-card-header" style="justify-content:space-between;">
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span class="status-dot completed"></span>
                        <span class="status-label" style="color:var(--blue);">Day Completed</span>
                    </div>
                    <?php if($todays_route['status'] == 'unloaded'): ?>
                    <span class="tag verified"><i class="bi bi-check2-all"></i> Verified</span>
                    <?php endif; ?>
                </div>
                <div class="route-card-body">
                    <div class="summary-row">
                        <span class="s-label">Start Meter</span>
                        <span class="s-value"><?php echo number_format($todays_route['start_meter'], 1); ?> km</span>
                    </div>
                    <div class="summary-row">
                        <span class="s-label">End Meter</span>
                        <span class="s-value"><?php echo number_format($todays_route['end_meter'], 1); ?> km</span>
                    </div>
                    <div class="summary-row highlight">
                        <span class="s-label">Distance</span>
                        <span class="s-value"><?php echo number_format($todays_route['end_meter'] - $todays_route['start_meter'], 1); ?> km</span>
                    </div>
                    <div class="summary-row">
                        <span class="s-label">Bills</span>
                        <span class="s-value"><?php echo $today_bills; ?></span>
                    </div>
                    <div class="summary-row highlight">
                        <span class="s-label">Gross Sales</span>
                        <span class="s-value">Rs <?php echo number_format($today_sales, 2); ?></span>
                    </div>
                </div>
            </div>

            <!-- State: Rejected -->
            <?php elseif ($todays_route['status'] == 'rejected'): ?>
            <div class="route-card">
                <div class="route-card-header">
                    <span class="status-dot rejected"></span>
                    <span class="status-label" style="color:var(--red);">Load Rejected</span>
                </div>
                <div class="route-card-body">
                    <div class="no-route-text">You rejected today's route/load assignment.</div>
                </div>
            </div>
            <?php endif; ?>

        <?php else: ?>
            <div class="no-route-notice" style="margin-top: 4px;">
                <div class="no-route-icon"><i class="bi bi-truck"></i></div>
                <div class="no-route-text">No vehicle dispatch or route has been assigned to you for today.</div>
            </div>
        <?php endif; ?>

        <!-- ── Menu ── -->
        <div class="section-title">Sales Menu</div>

        <a href="catalog.php" class="menu-item">
            <div class="menu-icon ic-blue"><i class="bi bi-grid-fill"></i></div>
            <div class="menu-text">
                <div class="menu-title">Digital Catalog</div>
                <div class="menu-sub">Browse items and add to cart</div>
            </div>
            <i class="bi bi-chevron-right menu-chevron"></i>
        </a>

        <a href="create_order.php?general=true" class="menu-item">
            <div class="menu-icon ic-mono"><i class="bi bi-receipt-cutoff"></i></div>
            <div class="menu-text">
                <div class="menu-title">General Invoice</div>
                <div class="menu-sub">Bill from main inventory anytime</div>
            </div>
            <i class="bi bi-chevron-right menu-chevron"></i>
        </a>

        <a href="create_order.php" class="menu-item">
            <div class="menu-icon ic-green"><i class="bi bi-receipt"></i></div>
            <div class="menu-text">
                <div class="menu-title">Quick Invoice (POS)</div>
                <div class="menu-sub">Bill directly from vehicle stock</div>
            </div>
            <i class="bi bi-chevron-right menu-chevron"></i>
        </a>

        <a href="todays_bills.php<?php echo $assignment_id ? '?assignment_id='.$assignment_id : ''; ?>" class="menu-item">
            <div class="menu-icon ic-blue"><i class="bi bi-list-check"></i></div>
            <div class="menu-text">
                <div class="menu-title">Active Route Bills</div>
                <div class="menu-sub">View invoices issued on this trip</div>
            </div>
            <i class="bi bi-chevron-right menu-chevron"></i>
        </a>

        <a href="process_return.php" class="menu-item">
            <div class="menu-icon ic-red"><i class="bi bi-arrow-return-left"></i></div>
            <div class="menu-text">
                <div class="menu-title">Customer Returns</div>
                <div class="menu-sub">Take back damaged or unsold items</div>
            </div>
            <i class="bi bi-chevron-right menu-chevron"></i>
        </a>

        <a href="analytics.php" class="menu-item">
            <div class="menu-icon ic-amber"><i class="bi bi-bar-chart-fill"></i></div>
            <div class="menu-text">
                <div class="menu-title">My Analytics</div>
                <div class="menu-sub">Track your monthly performance</div>
            </div>
            <i class="bi bi-chevron-right menu-chevron"></i>
        </a>

        <a href="route_history.php" class="menu-item">
            <div class="menu-icon ic-mono"><i class="bi bi-clock-history"></i></div>
            <div class="menu-text">
                <div class="menu-title">Route History</div>
                <div class="menu-sub">View past trips and sales data</div>
            </div>
            <i class="bi bi-chevron-right menu-chevron"></i>
        </a>

        <?php if($assignment_id && $todays_route['status'] == 'accepted' && !is_null($todays_route['start_meter'])): ?>
        <a href="#" class="menu-item" data-bs-toggle="modal" data-bs-target="#expensesModal">
            <div class="menu-icon ic-accent"><i class="bi bi-fuel-pump"></i></div>
            <div class="menu-text">
                <div class="menu-title">Route Expenses</div>
                <div class="menu-sub">Log fuel, meals, or repairs</div>
            </div>
            <i class="bi bi-chevron-right menu-chevron"></i>
        </a>
        <?php endif; ?>

        <a href="vehicle_stock.php" class="menu-item">
            <div class="menu-icon ic-blue"><i class="bi bi-box-seam-fill"></i></div>
            <div class="menu-text">
                <div class="menu-title">Vehicle Stock</div>
                <div class="menu-sub">Check remaining inventory in van</div>
            </div>
            <i class="bi bi-chevron-right menu-chevron"></i>
        </a>

        <?php if($pending_orders > 0): ?>
        <div class="warn-banner">
            <i class="bi bi-exclamation-triangle-fill warn-icon"></i>
            <div>
                <div class="warn-title">Action Required</div>
                <div class="warn-sub">You have <?php echo $pending_orders; ?> pending collection<?php echo $pending_orders > 1 ? 's' : ''; ?>.</div>
            </div>
        </div>
        <?php endif; ?>

    </div><!-- /page-content -->


    <!-- ═══════════════════════════════════════
         EXPENSES MODAL
    ═══════════════════════════════════════ -->
    <?php if ($assignment_id): ?>
    <div class="modal fade" id="expensesModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Route Expenses</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    
                    <?php if(count($route_expenses) > 0): ?>
                    <div style="margin-bottom:16px;">
                        <?php foreach($route_expenses as $exp): ?>
                        <div class="expense-item">
                            <div>
                                <div class="expense-item-name"><?php echo htmlspecialchars($exp['type']); ?></div>
                                <?php if($exp['description']): ?><div class="expense-item-desc"><?php echo htmlspecialchars($exp['description']); ?></div><?php endif; ?>
                            </div>
                            <div style="display:flex;align-items:center;gap:10px;">
                                <span class="expense-item-amount">−Rs <?php echo number_format($exp['amount'], 2); ?></span>
                                <form method="POST" class="d-inline" onsubmit="return confirm('Delete this expense?');">
                                    <input type="hidden" name="route_action" value="delete_expense">
                                    <input type="hidden" name="assignment_id" value="<?php echo $assignment_id; ?>">
                                    <input type="hidden" name="expense_id" value="<?php echo $exp['id']; ?>">
                                    <button type="submit" class="btn-del"><i class="bi bi-trash"></i></button>
                                </form>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>

                    <form method="POST">
                        <input type="hidden" name="route_action" value="add_expense">
                        <input type="hidden" name="assignment_id" value="<?php echo $assignment_id; ?>">
                        
                        <div style="margin-bottom:12px;">
                            <label class="form-label-sm">Expense Type</label>
                            <select name="expense_type" class="form-ctrl" required>
                                <option value="Fuel">Fuel</option>
                                <option value="Meals">Meals / Refreshments</option>
                                <option value="Vehicle Repair">Vehicle Repair / Tolls</option>
                                <option value="Other">Other Miscellaneous</option>
                            </select>
                        </div>
                        <div style="margin-bottom:12px;">
                            <label class="form-label-sm">Amount (Rs)</label>
                            <input type="number" step="0.01" name="expense_amount" class="form-ctrl" required placeholder="0.00">
                        </div>
                        <div style="margin-bottom:16px;">
                            <label class="form-label-sm">Description (Optional)</label>
                            <input type="text" name="expense_desc" class="form-ctrl" placeholder="e.g. Pumped diesel at IOC">
                        </div>
                        <button type="submit" class="btn-full dark">Add Expense</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>


    <!-- ═══════════════════════════════════════
         END DAY MODAL
    ═══════════════════════════════════════ -->
    <?php if ($todays_route && $todays_route['status'] == 'accepted' && !is_null($todays_route['start_meter'])): ?>
    <div class="modal fade" id="endDayModal" tabindex="-1" data-bs-backdrop="static">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" style="color:var(--red);">End Route &amp; Day</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">

                    <!-- Handover Summary -->
                    <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius);padding:14px;margin-bottom:16px;">
                        <div class="section-title" style="margin-top:0;">Expected Handover</div>
                        <div class="summary-row">
                            <span class="s-label">Cash Collected</span>
                            <span class="s-value" style="color:var(--green);">Rs <?php echo number_format($cash_sales, 2); ?></span>
                        </div>
                        <div class="summary-row">
                            <span class="s-label">Route Expenses</span>
                            <span class="s-value" style="color:var(--red);">−Rs <?php echo number_format($total_expenses, 2); ?></span>
                        </div>
                        <div class="summary-row highlight">
                            <span class="s-label">Net Handover</span>
                            <span class="s-value">Rs <?php echo number_format(max(0, $cash_sales - $total_expenses), 2); ?></span>
                            <input type="hidden" id="expected_cash_val" value="<?php echo max(0, $cash_sales - $total_expenses); ?>">
                        </div>
                        <?php if (count($collected_cheques) > 0): ?>
                        <div class="summary-row">
                            <span class="s-label">Cheques</span>
                            <span class="s-value"><?php echo count($collected_cheques); ?> cheque<?php echo count($collected_cheques) > 1 ? 's' : ''; ?></span>
                        </div>
                        <?php endif; ?>
                        <div style="margin-top:12px;">
                            <button type="button" class="btn-full outline" style="font-size:12px;padding:10px;" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#expensesModal">
                                Edit Expenses Before Closing
                            </button>
                        </div>
                    </div>

                    <form method="POST" id="endDayForm">
                        <input type="hidden" name="route_action" value="end_day">
                        <input type="hidden" name="assignment_id" value="<?php echo $todays_route['id']; ?>">
                        <input type="hidden" name="latitude" id="end_lat" value="">
                        <input type="hidden" name="longitude" id="end_lng" value="">

                        <!-- Cash denomination calculator -->
                        <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius);padding:14px;margin-bottom:16px;">
                            <div class="section-title" style="margin-top:0;">Count Handover Cash</div>
                            
                            <?php
                            $denoms = [5000 => '5,000', 2000 => '2,000', 1000 => '1,000', 500 => '500', 100 => '100', 50 => '50', 20 => '20'];
                            foreach($denoms as $val => $label): ?>
                            <div class="denom-row">
                                <div class="denom-label"><?php echo $label; ?></div>
                                <div style="font-size:12px;color:var(--text-tertiary);">×</div>
                                <input type="number" id="denom_<?php echo $val; ?>" class="denom-input cash-calc" min="0" inputmode="numeric" placeholder="0">
                            </div>
                            <?php endforeach; ?>
                            <div class="denom-row">
                                <div class="denom-label">Coins</div>
                                <div style="font-size:12px;color:var(--text-tertiary);">+</div>
                                <input type="number" step="0.01" id="denom_coins" class="denom-input cash-calc" min="0" inputmode="decimal" placeholder="0.00">
                            </div>

                            <div class="divider"></div>
                            
                            <div class="cash-summary-row">
                                <span class="cs-label">Counted Total</span>
                                <span class="cs-val" style="color:var(--green);">Rs <span id="actual_cash_total">0.00</span></span>
                                <input type="hidden" name="actual_cash_total_input" id="actual_cash_total_input" value="0">
                            </div>
                            <div class="cash-summary-row">
                                <span class="cs-label">Difference</span>
                                <span class="cs-val" id="cash_diff">0.00</span>
                            </div>
                        </div>
                        <input type="hidden" name="expected_cash_val" id="expected_cash_val_form" value="<?php echo max(0, $cash_sales - $total_expenses); ?>">

                        <div style="margin-bottom:16px;">
                            <div class="meter-label">Vehicle End Meter (km)</div>
                            <input type="text" inputmode="numeric" name="end_meter" class="meter-input" required placeholder="45250.5">
                        </div>

                        <button type="button" class="btn-full red" onclick="processEndDay(this);">Confirm End Day</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>


    <!-- ── Bottom Nav ── -->
    <nav class="bottom-nav">
        <a href="dashboard.php" class="nav-tab active">
            <i class="bi bi-house-door-fill"></i>
            Home
        </a>
        <a href="catalog.php" class="nav-tab">
            <i class="bi bi-grid-fill"></i>
            Catalog
        </a>
        <a href="create_order.php" class="nav-fab">
            <div class="fab-circle"><i class="bi bi-receipt"></i></div>
            <span class="fab-label">POS</span>
        </a>
        <a href="analytics.php" class="nav-tab">
            <i class="bi bi-bar-chart-fill"></i>
            Stats
        </a>
        <a href="route_history.php" class="nav-tab">
            <i class="bi bi-clock-history"></i>
            History
        </a>
    </nav>


    <script>
        // ── PWA Install ──
        let deferredPrompt;
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            const btn = document.getElementById('installAppBtn');
            if(btn) btn.classList.remove('d-none');
        });
        function installApp() {
            if (!deferredPrompt) return;
            deferredPrompt.prompt();
            deferredPrompt.userChoice.then((r) => {
                if (r.outcome === 'accepted') document.getElementById('installAppBtn').classList.add('d-none');
                deferredPrompt = null;
            });
        }
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => navigator.serviceWorker.register('sw.js'));
        }

        // ── Meter formatter ──
        document.querySelectorAll('.meter-input').forEach(input => {
            input.addEventListener('input', function() {
                let val = this.value.replace(/[^0-9]/g, '');
                if (val.length > 6) val = val.substring(0, 6);
                this.value = val.length === 6 ? val.substring(0, 5) + '.' + val.substring(5) : val;
            });
        });

        // ── Cash Calculator ──
        function calculateCash() {
            let total = 0;
            [5000, 2000, 1000, 500, 100, 50, 20].forEach(d => {
                total += (parseInt(document.getElementById('denom_' + d)?.value) || 0) * d;
            });
            total += parseFloat(document.getElementById('denom_coins')?.value) || 0;

            document.getElementById('actual_cash_total').innerText = total.toFixed(2);
            document.getElementById('actual_cash_total_input').value = total.toFixed(2);

            const expected = parseFloat(document.getElementById('expected_cash_val')?.value) || 0;
            const diff = total - expected;
            const el = document.getElementById('cash_diff');
            if (el) {
                el.innerText = (diff >= 0 ? '+' : '') + diff.toFixed(2);
                el.style.color = diff >= 0 ? 'var(--green)' : 'var(--red)';
            }
        }
        document.querySelectorAll('.cash-calc').forEach(i => i.addEventListener('input', calculateCash));

        // ── Start Day ──
        function processStartDay(btn) {
            if (!document.querySelector('input[name="start_meter"]').value) {
                alert('Please enter start meter.'); return;
            }
            if (!confirm('Starting your day will officially record attendance. Proceed?')) return;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm" style="border-width:2px;"></span> Locating…';
            btn.disabled = true;
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    pos => { document.getElementById('start_lat').value = pos.coords.latitude; document.getElementById('start_lng').value = pos.coords.longitude; document.getElementById('startDayForm').submit(); },
                    () => document.getElementById('startDayForm').submit(),
                    { enableHighAccuracy: true, timeout: 5000 }
                );
            } else { document.getElementById('startDayForm').submit(); }
        }

        // ── End Day ──
        function processEndDay(btn) {
            if (!document.querySelector('input[name="end_meter"]').value) {
                alert('Please enter end meter.'); return;
            }
            if (!confirm('End your day? You will not be able to create more invoices on this route.')) return;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm" style="border-width:2px;"></span> Locating…';
            btn.disabled = true;
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    pos => { document.getElementById('end_lat').value = pos.coords.latitude; document.getElementById('end_lng').value = pos.coords.longitude; document.getElementById('endDayForm').submit(); },
                    () => document.getElementById('endDayForm').submit(),
                    { enableHighAccuracy: true, timeout: 5000 }
                );
            } else { document.getElementById('endDayForm').submit(); }
        }

        // ── Background Location Ping ──
        <?php if ($todays_route && $todays_route['status'] == 'accepted' && !is_null($todays_route['start_meter'])): ?>
        function sendLocationPing() {
            if (!navigator.geolocation) return;
            navigator.geolocation.getCurrentPosition(pos => {
                fetch('../ajax/log_location.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ latitude: pos.coords.latitude, longitude: pos.coords.longitude, activity: 'background_ping' })
                }).catch(() => {});
            }, () => {}, { enableHighAccuracy: true });
        }
        sendLocationPing();
        setInterval(sendLocationPing, 120000);
        <?php endif; ?>
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>