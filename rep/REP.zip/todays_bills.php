<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/db.php';
require_once '../includes/auth_check.php';
requireRole(['rep']); // Strictly for Sales Reps

$rep_id = $_SESSION['user_id'];
$message = '';

// Check if filtering by isolated route assignment
$assignment_id = isset($_GET['assignment_id']) && $_GET['assignment_id'] !== '' ? (int)$_GET['assignment_id'] : null;

// --- HANDLE DELETE ACTION ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'delete_order') {
    $order_id = (int)$_POST['order_id'];
    
    try {
        $pdo->beginTransaction();
        
        // Verify this order belongs to this rep and is from today
        $verifyStmt = $pdo->prepare("SELECT id FROM orders WHERE id = ? AND rep_id = ? AND DATE(created_at) = CURDATE()");
        $verifyStmt->execute([$order_id, $rep_id]);
        if (!$verifyStmt->fetch()) {
            throw new Exception("Unauthorized to delete this order or it is not from today.");
        }

        // Fetch items to reverse stock
        $itemsStmt = $pdo->prepare("SELECT product_id, quantity FROM order_items WHERE order_id = ?");
        $itemsStmt->execute([$order_id]);
        $items = $itemsStmt->fetchAll();
        
        $revertStockStmt = $pdo->prepare("UPDATE products SET stock = stock + ? WHERE id = ?");
        $logStmt = $pdo->prepare("INSERT INTO stock_logs (product_id, type, reference_id, qty_change, previous_stock, new_stock, created_by) VALUES (?, 'returned', ?, ?, (SELECT stock + ? FROM products WHERE id = ?), (SELECT stock FROM products WHERE id = ?), ?)");
        
        foreach($items as $item) {
            $revertStockStmt->execute([$item['quantity'], $item['product_id']]);
            $logStmt->execute([$item['product_id'], $order_id, $item['quantity'], $item['quantity'], $item['product_id'], $item['product_id'], $rep_id]);
        }
        
        // Remove associated cheques and delete the order
        $pdo->prepare("DELETE FROM cheques WHERE order_id = ?")->execute([$order_id]);
        $pdo->prepare("DELETE FROM orders WHERE id = ?")->execute([$order_id]);
        
        $pdo->commit();
        $message = "<div class='alert alert-success m-3 rounded-4 shadow-sm border-0 fw-bold'><i class='bi bi-check-circle'></i> Order #".str_pad($order_id, 6, '0', STR_PAD_LEFT)." deleted and stock safely restored!</div>";
    } catch (Exception $e) {
        $pdo->rollBack();
        $message = "<div class='alert alert-danger m-3 rounded-4 shadow-sm border-0 fw-bold'><i class='bi bi-x-circle'></i> Error: " . $e->getMessage() . "</div>";
    }
}

// --- FETCH ORDERS ISOLATED BY ROUTE ASSIGNMENT ---
$routeName = "Today's Bills";
if ($assignment_id) {
    // Fetch specifically for this dispatch assignment
    $routeStmt = $pdo->prepare("SELECT r.name FROM rep_routes rr JOIN routes r ON rr.route_id = r.id WHERE rr.id = ?");
    $routeStmt->execute([$assignment_id]);
    $fetchedName = $routeStmt->fetchColumn();
    if ($fetchedName) $routeName = $fetchedName . " Bills";
    
    $stmt = $pdo->prepare("
        SELECT o.*, c.name as customer_name 
        FROM orders o 
        LEFT JOIN customers c ON o.customer_id = c.id 
        WHERE o.assignment_id = ? 
        ORDER BY o.created_at DESC
    ");
    $stmt->execute([$assignment_id]);
} else {
    // Fallback: Fetch all today's orders globally
    $stmt = $pdo->prepare("
        SELECT o.*, c.name as customer_name 
        FROM orders o 
        LEFT JOIN customers c ON o.customer_id = c.id 
        WHERE o.rep_id = ? AND DATE(o.created_at) = CURDATE() 
        ORDER BY o.created_at DESC
    ");
    $stmt->execute([$rep_id]);
}

$orders = $stmt->fetchAll();

// Calculate total sales
$totalSales = 0;
foreach($orders as $o) {
    $totalSales += $o['total_amount'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $routeName; ?> - Rep App</title>
    
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#0d6efd">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        body { background-color: #f4f7f6; padding-bottom: 90px; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; -webkit-tap-highlight-color: transparent; }
        
        .top-nav { background: #0d6efd; color: white; padding: 15px 20px; position: sticky; top: 0; z-index: 1000; box-shadow: 0 4px 15px rgba(13,110,253,0.2); }
        .back-btn { color: white; font-size: 1.2rem; text-decoration: none; margin-right: 15px; }

        .order-card { background: white; border-radius: 16px; padding: 15px; margin-bottom: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.04); border: 1px solid #f8f9fa; }
        
        .bottom-nav { position: fixed; bottom: 0; left: 0; right: 0; background: white; box-shadow: 0 -4px 15px rgba(0,0,0,0.05); display: flex; justify-content: space-around; padding: 12px 0 8px 0; z-index: 1000; border-top-left-radius: 20px; border-top-right-radius: 20px; }
        .nav-item { text-align: center; color: #adb5bd; text-decoration: none; font-size: 0.75rem; flex: 1; }
        .nav-item.active { color: #0d6efd; font-weight: 700; }
        .nav-item i { font-size: 1.4rem; display: block; margin-bottom: 3px; }
        .nav-item.fab-button { position: relative; top: -20px; }
        .nav-item.fab-button .fab-icon { background: #0d6efd; color: white; width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 3px auto; box-shadow: 0 4px 10px rgba(13,110,253,0.3); font-size: 1.5rem; }
    </style>
</head>
<body>

    <div class="top-nav d-flex align-items-center">
        <a href="dashboard.php" class="back-btn"><i class="bi bi-arrow-left"></i></a>
        <div>
            <h5 class="mb-0 fw-bold"><?php echo htmlspecialchars($routeName); ?></h5>
            <small class="text-white text-opacity-75"><?php echo date('M d, Y'); ?></small>
        </div>
    </div>

    <?php echo $message; ?>

    <div class="container px-3 mt-4">
        
        <div class="d-flex justify-content-between align-items-center mb-3 px-1">
            <span class="text-muted fw-bold small text-uppercase">Generated Invoices (<?php echo count($orders); ?>)</span>
            <span class="fw-bold text-success fs-5">Rs <?php echo number_format($totalSales, 2); ?></span>
        </div>

        <?php if (empty($orders)): ?>
            <div class="alert alert-info border-0 shadow-sm rounded-4 text-center p-4 mt-4">
                <i class="bi bi-receipt fs-1 d-block mb-2 text-info"></i>
                <h6 class="fw-bold">No Bills Today</h6>
                <p class="small mb-0">You haven't generated any invoices today.</p>
                <a href="create_order.php" class="btn btn-primary mt-3 rounded-pill px-4 fw-bold">Create Invoice</a>
            </div>
        <?php else: ?>
            
            <?php foreach ($orders as $o): ?>
            <div class="order-card">
                <div class="d-flex justify-content-between align-items-start mb-2 border-bottom pb-2">
                    <div>
                        <h6 class="fw-bold text-primary mb-1">#<?php echo str_pad($o['id'], 6, '0', STR_PAD_LEFT); ?></h6>
                        <div class="small text-dark fw-bold"><i class="bi bi-shop"></i> <?php echo htmlspecialchars($o['customer_name'] ?: 'Walk-in Customer'); ?></div>
                    </div>
                    <div class="text-end">
                        <div class="fw-bold text-success fs-5">Rs <?php echo number_format($o['total_amount'], 2); ?></div>
                        <div class="small text-muted"><?php echo date('h:i A', strtotime($o['created_at'])); ?></div>
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="badge bg-secondary bg-opacity-10 text-dark border px-2 py-1"><?php echo htmlspecialchars($o['payment_method']); ?></span>
                    <?php if($o['payment_status'] == 'paid'): ?>
                        <span class="badge bg-success bg-opacity-10 text-success border border-success"><i class="bi bi-check-circle"></i> Paid</span>
                    <?php elseif($o['payment_status'] == 'waiting'): ?>
                        <span class="badge bg-info bg-opacity-10 text-info border border-info"><i class="bi bi-clock-history"></i> Waiting (Chq)</span>
                    <?php else: ?>
                        <span class="badge bg-warning bg-opacity-10 text-dark border border-warning"><i class="bi bi-hourglass-split"></i> Pending</span>
                    <?php endif; ?>
                </div>

                <div class="row g-2">
                    <div class="col-4">
                        <a href="../pages/view_invoice.php?id=<?php echo $o['id']; ?>" class="btn btn-outline-info w-100 rounded-pill fw-bold shadow-sm">
                            <i class="bi bi-eye"></i> View
                        </a>
                    </div>
                    <div class="col-4">
                        <a href="create_order.php?edit_id=<?php echo $o['id']; ?>&customer_id=<?php echo $o['customer_id'] ?: '0'; ?>" class="btn btn-outline-primary w-100 rounded-pill fw-bold shadow-sm">
                            <i class="bi bi-pencil"></i> Edit
                        </a>
                    </div>
                    <div class="col-4">
                        <form method="POST" onsubmit="return confirm('Are you sure you want to completely delete Invoice #<?php echo str_pad($o['id'], 6, '0', STR_PAD_LEFT); ?>? The items will be returned to your vehicle stock.');">
                            <input type="hidden" name="action" value="delete_order">
                            <input type="hidden" name="order_id" value="<?php echo $o['id']; ?>">
                            <button type="submit" class="btn btn-outline-danger w-100 rounded-pill fw-bold shadow-sm">
                                <i class="bi bi-trash"></i> Del
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>

        <?php endif; ?>
    </div>

    <!-- Mobile Bottom Navigation -->
    <div class="bottom-nav">
        <a href="dashboard.php" class="nav-item">
            <i class="bi bi-house-door-fill"></i> Home
        </a>
        <a href="customers.php?filter=route" class="nav-item">
            <i class="bi bi-people-fill"></i> Clients
        </a>
        <a href="create_order.php" class="nav-item fab-button">
            <div class="fab-icon"><i class="bi bi-receipt mt-1"></i></div>
            <span class="text-dark fw-bold">POS</span>
        </a>
        <a href="todays_bills.php" class="nav-item active">
            <i class="bi bi-clock-history"></i> History
        </a>
        <a href="../pages/product_gallery.php" class="nav-item">
            <i class="bi bi-grid-fill"></i> Catalog
        </a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>