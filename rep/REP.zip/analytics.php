<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/db.php';
require_once '../includes/auth_check.php';
requireRole(['rep']); // Strictly for Sales Reps

$rep_id = $_SESSION['user_id'];

// --- 1. Fetch KPI Metrics ---
// Month-to-Date Sales
$mtdStmt = $pdo->prepare("SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE rep_id = ? AND MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())");
$mtdStmt->execute([$rep_id]);
$mtd_sales = (float)$mtdStmt->fetchColumn();

// Month-to-Date Bills
$mtdBillsStmt = $pdo->prepare("SELECT COUNT(id) FROM orders WHERE rep_id = ? AND MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())");
$mtdBillsStmt->execute([$rep_id]);
$mtd_bills = (int)$mtdBillsStmt->fetchColumn();

// Total Outstanding for Rep's Customers
$outStmt = $pdo->prepare("SELECT COALESCE(SUM(total_amount - paid_amount), 0) FROM orders WHERE rep_id = ? AND payment_status != 'paid'");
$outStmt->execute([$rep_id]);
$total_outstanding = (float)$outStmt->fetchColumn();

// --- 2. Fetch Rep Sales Target ---
$targetStmt = $pdo->prepare("SELECT target_amount FROM rep_targets WHERE rep_id = ? AND month = ?");
$targetStmt->execute([$rep_id, date('Y-m')]);
$monthly_target = (float)$targetStmt->fetchColumn();
$target_progress = ($monthly_target > 0) ? ($mtd_sales / $monthly_target) * 100 : 0;

// --- 3. Fetch Last 7 Days Sales for Chart ---
$chartLabels = [];
$salesDataRaw = [];

// Initialize array with last 7 days set to 0
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $label = date('M d', strtotime("-$i days"));
    $chartLabels[] = $label;
    $salesDataRaw[$date] = 0;
}

$chartStmt = $pdo->prepare("
    SELECT DATE(created_at) as sale_date, SUM(total_amount) as daily_total 
    FROM orders 
    WHERE rep_id = ? AND created_at >= DATE(NOW() - INTERVAL 7 DAY) 
    GROUP BY DATE(created_at)
");
$chartStmt->execute([$rep_id]);

foreach ($chartStmt->fetchAll() as $row) {
    if (isset($salesDataRaw[$row['sale_date']])) {
        $salesDataRaw[$row['sale_date']] = (float)$row['daily_total'];
    }
}
$chartData = array_values($salesDataRaw);

// --- 4. Fetch Top 5 Products Sold by Rep ---
$topProductsStmt = $pdo->prepare("
    SELECT p.name, SUM(oi.quantity) as total_qty, SUM(oi.quantity * oi.price) as revenue
    FROM order_items oi
    JOIN orders o ON oi.order_id = o.id
    JOIN products p ON oi.product_id = p.id
    WHERE o.rep_id = ? AND MONTH(o.created_at) = MONTH(CURDATE())
    GROUP BY p.id
    ORDER BY total_qty DESC
    LIMIT 5
");
$topProductsStmt->execute([$rep_id]);
$top_products = $topProductsStmt->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>My Analytics - Rep App</title>
    
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#0d6efd">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <!-- Chart.js for Graphs -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        body { background-color: #f4f7f6; padding-bottom: 90px; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; -webkit-tap-highlight-color: transparent; }
        
        .top-nav { background: #0d6efd; color: white; padding: 15px 20px; position: sticky; top: 0; z-index: 1000; box-shadow: 0 4px 15px rgba(13,110,253,0.2); }
        .back-btn { color: white; font-size: 1.2rem; text-decoration: none; margin-right: 15px; }

        .metric-card { background: white; border-radius: 16px; padding: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.04); border: 1px solid #f8f9fa; }
        
        .bottom-nav { position: fixed; bottom: 0; left: 0; right: 0; background: white; box-shadow: 0 -4px 15px rgba(0,0,0,0.05); display: flex; justify-content: space-around; padding: 12px 0 8px 0; z-index: 1000; border-top-left-radius: 20px; border-top-right-radius: 20px; }
        .nav-item { text-align: center; color: #adb5bd; text-decoration: none; font-size: 0.75rem; flex: 1; }
        .nav-item.active { color: #0d6efd; font-weight: 700; }
        .nav-item i { font-size: 1.4rem; display: block; margin-bottom: 3px; }
        .nav-item.fab-button { position: relative; top: -20px; }
        .nav-item.fab-button .fab-icon { background: #0d6efd; color: white; width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 3px auto; box-shadow: 0 4px 10px rgba(13,110,253,0.3); font-size: 1.5rem; }
    </style>
</head>
<body>

    <div class="top-nav d-flex align-items-center">
        <a href="dashboard.php" class="back-btn"><i class="bi bi-arrow-left"></i></a>
        <div>
            <h5 class="mb-0 fw-bold">My Analytics</h5>
            <small class="text-white text-opacity-75"><?php echo date('F Y'); ?> Performance</small>
        </div>
    </div>

    <div class="container px-3 mt-4">
        
        <!-- TARGET ACHIEVING CARD -->
        <?php if ($monthly_target > 0): ?>
        <div class="metric-card mb-4 border-info border-2 border-start">
            <div class="d-flex justify-content-between align-items-end mb-2">
                <div class="text-info small fw-bold text-uppercase"><i class="bi bi-bullseye"></i> Monthly Target Progress</div>
                <div class="fw-bold text-dark fs-5"><?php echo number_format(min(100, $target_progress), 1); ?>%</div>
            </div>
            <div class="progress mb-2 bg-light border shadow-sm" style="height: 12px;">
                <div class="progress-bar bg-info progress-bar-striped progress-bar-animated" style="width: <?php echo min(100, $target_progress); ?>%"></div>
            </div>
            <div class="d-flex justify-content-between small text-muted fw-bold mt-2">
                <span>Achieved: Rs <?php echo number_format($mtd_sales, 2); ?></span>
                <span>Goal: Rs <?php echo number_format($monthly_target, 2); ?></span>
            </div>
        </div>
        <?php else: ?>
        <div class="alert alert-light border shadow-sm rounded-4 small fw-bold text-muted text-center mb-4">
            <i class="bi bi-info-circle"></i> No sales target set for this month.
        </div>
        <?php endif; ?>

        <!-- Summary KPIs -->
        <div class="row g-3 mb-4">
            <div class="col-12">
                <div class="metric-card bg-primary bg-opacity-10 border-primary border-opacity-25 border-start border-4">
                    <div class="text-primary small fw-bold text-uppercase mb-1"><i class="bi bi-graph-up-arrow"></i> Month-to-Date Sales</div>
                    <h2 class="fw-bold text-dark mb-0">Rs <?php echo number_format($mtd_sales, 2); ?></h2>
                    <div class="text-muted small mt-1"><?php echo $mtd_bills; ?> Total Bills Generated</div>
                </div>
            </div>
            
            <div class="col-12">
                <div class="metric-card bg-danger bg-opacity-10 border-danger border-opacity-25 border-start border-4">
                    <div class="text-danger small fw-bold text-uppercase mb-1"><i class="bi bi-exclamation-circle"></i> Pending Collections</div>
                    <h3 class="fw-bold text-dark mb-0">Rs <?php echo number_format($total_outstanding, 2); ?></h3>
                    <div class="text-muted small mt-1">Total outstanding from your clients</div>
                </div>
            </div>
        </div>

        <!-- Sales Chart -->
        <div class="metric-card mb-4 pb-4">
            <h6 class="fw-bold text-muted text-uppercase mb-3"><i class="bi bi-bar-chart"></i> Last 7 Days Sales</h6>
            <!-- Strict height wrapper to fix infinite expanding issue -->
            <div style="position: relative; height: 250px; width: 100%;">
                <canvas id="salesChart"></canvas>
            </div>
        </div>

        <!-- Top Products -->
        <h6 class="fw-bold text-muted small text-uppercase px-1 mb-2"><i class="bi bi-trophy"></i> Top Products (This Month)</h6>
        <div class="metric-card p-0 overflow-hidden mb-4">
            <ul class="list-group list-group-flush">
                <?php foreach($top_products as $index => $prod): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center p-3">
                        <div class="d-flex align-items-center">
                            <span class="fw-bold text-muted me-3 fs-5">#<?php echo $index + 1; ?></span>
                            <div>
                                <h6 class="mb-0 fw-bold text-dark" style="font-size: 0.95rem;"><?php echo htmlspecialchars($prod['name']); ?></h6>
                                <small class="text-muted"><?php echo $prod['total_qty']; ?> Units Sold</small>
                            </div>
                        </div>
                        <div class="text-end">
                            <span class="fw-bold text-success" style="font-size: 0.85rem;">Rs <?php echo number_format($prod['revenue'], 0); ?></span>
                        </div>
                    </li>
                <?php endforeach; ?>
                
                <?php if(empty($top_products)): ?>
                    <li class="list-group-item text-center text-muted py-4">No sales recorded this month.</li>
                <?php endif; ?>
            </ul>
        </div>

    </div>

    <!-- Mobile Bottom Navigation (Updated with Stats) -->
    <div class="bottom-nav">
        <a href="dashboard.php" class="nav-item">
            <i class="bi bi-house-door-fill"></i> Home
        </a>
        <a href="customers.php?filter=route" class="nav-item">
            <i class="bi bi-people-fill"></i> Clients
        </a>
        <a href="create_order.php" class="nav-item fab-button">
            <div class="fab-icon"><i class="bi bi-receipt mt-1"></i></div>
            <span class="text-dark fw-bold">POS</span>
        </a>
        <a href="analytics.php" class="nav-item active">
            <i class="bi bi-bar-chart-fill"></i> Stats
        </a>
        <a href="route_history.php" class="nav-item">
            <i class="bi bi-clock-history"></i> History
        </a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Chart.js Initialization
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('salesChart').getContext('2d');
            
            const gradient = ctx.createLinearGradient(0, 0, 0, 200);
            gradient.addColorStop(0, 'rgba(13, 110, 253, 0.5)'); // primary blue
            gradient.addColorStop(1, 'rgba(13, 110, 253, 0.05)');

            const labels = <?php echo json_encode($chartLabels); ?>;
            const data = <?php echo json_encode($chartData); ?>;

            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Gross Sales (Rs)',
                        data: data,
                        backgroundColor: gradient,
                        borderColor: '#0d6efd',
                        borderWidth: 2,
                        borderRadius: 6,
                        borderSkipped: false,
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false, // Prevents infinite stretching
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return 'Rs: ' + context.parsed.y.toLocaleString();
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    if(value >= 1000) return (value/1000) + 'k';
                                    return value;
                                }
                            }
                        },
                        x: {
                            grid: { display: false }
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>