<?php
require_once '../config/db.php';
require_once '../includes/auth_check.php';
requireRole(['rep']); // Strictly for Sales Reps

$rep_id = $_SESSION['user_id'];
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';

// 1. Verify Active Route / Started Day
$routeStmt = $pdo->prepare("SELECT id FROM rep_routes WHERE rep_id = ? AND assign_date = CURDATE() AND status = 'accepted' AND start_meter IS NOT NULL ORDER BY id DESC LIMIT 1");
$routeStmt->execute([$rep_id]);
$assignment_id = $routeStmt->fetchColumn();

// 2. Fetch Available Stock (Vehicle or Main Inventory)
$vehicle_stock = [];
$searchSql = "";
$params = [];

if ($search_query !== '') {
    $searchSql = " AND (p.name LIKE ? OR p.sku LIKE ?)";
    $params[] = "%$search_query%";
    $params[] = "%$search_query%";
}

if ($assignment_id) {
    // If active route, fetch vehicle stock
    $stockQuery = "
        SELECT 
            p.id as product_id, p.name, p.sku, p.selling_price, p.supplier_id,
            rl.loaded_qty,
            (rl.loaded_qty - COALESCE((
                SELECT SUM(oi.quantity) 
                FROM order_items oi 
                JOIN orders o ON oi.order_id = o.id 
                WHERE o.assignment_id = ? AND oi.product_id = p.id
            ), 0)) as remaining_qty,
            (SELECT image_path FROM product_images WHERE product_id = p.id LIMIT 1) as primary_image
        FROM route_loads rl
        JOIN products p ON rl.product_id = p.id
        WHERE rl.assignment_id = ? $searchSql
        HAVING remaining_qty > 0
        ORDER BY p.name ASC
    ";
    $final_params = array_merge([$assignment_id, $assignment_id], $params);
} else {
    // If no active route, fetch main inventory stock (for General Invoicing)
    $stockQuery = "
        SELECT 
            p.id as product_id, p.name, p.sku, p.selling_price, p.supplier_id,
            p.stock as loaded_qty,
            p.stock as remaining_qty,
            (SELECT image_path FROM product_images WHERE product_id = p.id LIMIT 1) as primary_image
        FROM products p
        WHERE p.status = 'available' AND p.stock > 0 $searchSql
        ORDER BY p.name ASC
    ";
    $final_params = $params;
}

$stmt = $pdo->prepare($stockQuery);
$stmt->execute($final_params);
$vehicle_stock = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Digital Catalog - Rep App</title>
    
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#0d6efd">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        body { background-color: #f4f7f6; padding-bottom: 90px; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; -webkit-tap-highlight-color: transparent; }
        
        .top-nav { background: #0d6efd; color: white; padding: 15px 20px; position: sticky; top: 0; z-index: 1000; box-shadow: 0 4px 15px rgba(13,110,253,0.2); }
        .back-btn { color: white; font-size: 1.2rem; text-decoration: none; margin-right: 15px; }

        .catalog-card { transition: transform 0.1s; cursor: pointer; }
        .catalog-card:active { transform: scale(0.96); }

        .floating-cart-btn { position: fixed; bottom: 85px; left: 20px; right: 20px; background: #198754; color: white; border-radius: 16px; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 8px 20px rgba(25,135,84,0.3); z-index: 1000; text-decoration: none; border: none; width: calc(100% - 40px); }
        .floating-cart-btn:active { transform: scale(0.98); }
        
        .bottom-nav { position: fixed; bottom: 0; left: 0; right: 0; background: white; box-shadow: 0 -4px 15px rgba(0,0,0,0.05); display: flex; justify-content: space-around; padding: 12px 0 8px 0; z-index: 1000; border-top-left-radius: 20px; border-top-right-radius: 20px; }
        .nav-item { text-align: center; color: #adb5bd; text-decoration: none; font-size: 0.75rem; flex: 1; }
        .nav-item.active { color: #0d6efd; font-weight: 700; }
        .nav-item i { font-size: 1.4rem; display: block; margin-bottom: 3px; }
        .nav-item.fab-button { position: relative; top: -20px; }
        .nav-item.fab-button .fab-icon { background: #0d6efd; color: white; width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 3px auto; box-shadow: 0 4px 10px rgba(13,110,253,0.3); font-size: 1.5rem; }
    </style>
</head>
<body>

    <div class="top-nav d-flex align-items-center">
        <a href="dashboard.php" class="back-btn"><i class="bi bi-arrow-left"></i></a>
        <div>
            <h5 class="mb-0 fw-bold">Digital Catalog</h5>
            <small class="text-white text-opacity-75"><?php echo $assignment_id ? 'Live Vehicle Stock' : 'Main Warehouse Stock'; ?></small>
        </div>
    </div>

    <div class="container px-3 mt-4">

        <!-- Search Bar -->
        <form method="GET" action="" class="d-flex shadow-sm rounded-pill overflow-hidden bg-white mb-4 border">
            <span class="ps-3 pe-2 py-2 text-muted d-flex align-items-center"><i class="bi bi-search"></i></span>
            <input type="text" name="search" class="form-control border-0 shadow-none ps-1 py-2" placeholder="Search products..." value="<?php echo htmlspecialchars($search_query); ?>">
            <?php if($search_query): ?>
                <a href="catalog.php" class="btn text-danger py-2 px-3"><i class="bi bi-x-circle-fill"></i></a>
            <?php endif; ?>
        </form>

        <?php if(empty($vehicle_stock)): ?>
            <div class="alert alert-warning text-center small fw-bold rounded-4 shadow-sm border-0 py-4">
                <i class="bi bi-box-seam fs-2 d-block mb-2"></i> 
                <?php echo $search_query ? 'No products found matching your search.' : 'Inventory is out of stock!'; ?>
            </div>
        <?php else: ?>
            <!-- Product Grid -->
            <div class="row row-cols-2 g-3 pb-5">
                <?php foreach($vehicle_stock as $p): ?>
                <div class="col">
                    <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden catalog-card" 
                        onclick='openProductModal(<?php echo json_encode($p, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'>
                        
                        <?php if($p['primary_image']): ?>
                            <img src="../assets/images/products/<?php echo htmlspecialchars($p['primary_image']); ?>" class="card-img-top object-fit-cover" style="height: 130px;" alt="<?php echo htmlspecialchars($p['name']); ?>">
                        <?php else: ?>
                            <div class="card-img-top bg-light d-flex align-items-center justify-content-center text-muted" style="height: 130px;">
                                <i class="bi bi-image fs-1"></i>
                            </div>
                        <?php endif; ?>
                        
                        <div class="p-2 d-flex flex-column h-100">
                            <div class="fw-bold text-dark mb-1" style="font-size: 0.85rem; line-height: 1.2; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                                <?php echo htmlspecialchars($p['name']); ?>
                            </div>
                            <div class="d-flex justify-content-between align-items-end mt-auto pt-2">
                                <span class="text-success fw-bold" style="font-size: 0.9rem;">Rs <?php echo number_format($p['selling_price'], 2); ?></span>
                                <span class="badge bg-primary bg-opacity-10 text-primary border border-primary px-1 py-1" style="font-size: 0.65rem;">Stock: <?php echo $p['remaining_qty']; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Floating Checkout Button -->
    <button type="button" class="floating-cart-btn d-none" id="mainCheckoutBtn">
        <div class="d-flex align-items-center">
            <div class="bg-white text-success rounded-circle d-flex align-items-center justify-content-center fw-bold me-2" style="width: 30px; height: 30px;" id="cartItemCount">0</div>
            <span class="fw-bold">Continue to POS <i class="bi bi-arrow-right"></i></span>
        </div>
        <div class="fw-bold fs-5">Rs <span id="cartTotalBtn">0.00</span></div>
    </button>

    <!-- Product Entry Modal -->
    <div class="modal fade" id="productModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 rounded-4 shadow">
                <div class="modal-header bg-light border-bottom-0 pb-2">
                    <h5 class="modal-title fw-bold text-dark" id="modalProdName">Product Name</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body pt-0">
                    <div class="text-muted small mb-3">Available Stock: <span id="modalProdStock" class="fw-bold text-primary">0</span></div>
                    
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label fw-bold small text-muted">Quantity</label>
                            <input type="number" id="modalQty" class="form-control form-control-lg fw-bold text-center" value="1" min="1">
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold small text-muted">Unit Price (Rs)</label>
                            <input type="number" id="modalPrice" class="form-control form-control-lg fw-bold text-success text-center" step="0.01">
                        </div>
                        
                        <div class="col-12 mt-3">
                            <label class="form-label fw-bold small text-muted">Item Discount (Optional)</label>
                            <div class="input-group input-group-lg shadow-sm border rounded">
                                <select id="modalDisType" class="form-select bg-light fw-bold border-0" style="max-width: 90px;">
                                    <option value="%">%</option>
                                    <option value="Rs">Rs</option>
                                </select>
                                <input type="number" id="modalDisValue" class="form-control fw-bold text-danger border-0" value="0" min="0" step="0.01">
                            </div>
                        </div>
                    </div>

                    <div class="bg-light p-3 rounded-4 mt-4 d-flex justify-content-between align-items-center border">
                        <span class="fw-bold text-muted">Item Net Total:</span>
                        <span class="fs-4 fw-bold text-dark">Rs <span id="modalNetTotal">0.00</span></span>
                    </div>
                </div>
                <div class="modal-footer border-top-0 pt-0">
                    <button type="button" class="btn btn-primary btn-lg w-100 rounded-pill fw-bold shadow-sm" id="btnAddToCart">Add to Cart</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile Bottom Navigation -->
    <div class="bottom-nav">
        <a href="dashboard.php" class="nav-item">
            <i class="bi bi-house-door-fill"></i> Home
        </a>
        <a href="catalog.php" class="nav-item active">
            <i class="bi bi-grid-fill"></i> Catalog
        </a>
        <a href="create_order.php" class="nav-item fab-button">
            <div class="fab-icon"><i class="bi bi-receipt mt-1"></i></div>
            <span class="text-dark fw-bold">POS</span>
        </a>
        <a href="analytics.php" class="nav-item">
            <i class="bi bi-bar-chart-fill"></i> Stats
        </a>
        <a href="route_history.php" class="nav-item">
            <i class="bi bi-clock-history"></i> History
        </a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        
        const cartBtn = document.getElementById('mainCheckoutBtn');
        const countBadge = document.getElementById('cartItemCount');
        const totalBtnText = document.getElementById('cartTotalBtn');
        
        const prodModal = new bootstrap.Modal(document.getElementById('productModal'));
        const modalQty = document.getElementById('modalQty');
        const modalPrice = document.getElementById('modalPrice');
        const modalDisType = document.getElementById('modalDisType');
        const modalDisValue = document.getElementById('modalDisValue');
        const modalNetTotal = document.getElementById('modalNetTotal');

        let cart = [];
        let activeProductData = null; 

        // Load existing cart from localStorage if exists
        const savedCart = localStorage.getItem('fintrix_rep_pos_cart');
        if (savedCart) {
            try {
                cart = JSON.parse(savedCart);
                updateCartUI();
            } catch(e) {}
        }

        window.openProductModal = function(product) {
            activeProductData = product;
            
            document.getElementById('modalProdName').textContent = product.name;
            document.getElementById('modalProdStock').textContent = product.remaining_qty;
            
            const existing = cart.find(c => c.product_id == product.product_id);
            if (existing) {
                modalQty.value = existing.quantity;
                modalPrice.value = existing.sell_price.toFixed(2);
                modalDisType.value = existing.dis_type;
                modalDisValue.value = existing.dis_value;
            } else {
                modalQty.value = 1;
                modalPrice.value = parseFloat(product.selling_price).toFixed(2);
                modalDisType.value = '%';
                modalDisValue.value = 0;
            }
            
            modalQty.max = product.remaining_qty;
            calculateModalNet();
            prodModal.show();
        };

        function calculateModalNet() {
            if(!activeProductData) return;
            const qty = parseFloat(modalQty.value) || 0;
            const price = parseFloat(modalPrice.value) || 0;
            const dType = modalDisType.value;
            const dVal = parseFloat(modalDisValue.value) || 0;
            
            const gross = qty * price;
            let disAmt = dType === '%' ? gross * (dVal / 100) : dVal * qty;
            
            modalNetTotal.textContent = (gross - disAmt).toFixed(2);
        }

        [modalQty, modalPrice, modalDisType, modalDisValue].forEach(el => el.addEventListener('input', calculateModalNet));

        document.getElementById('btnAddToCart').addEventListener('click', function() {
            const qty = parseInt(modalQty.value) || 0;
            const price = parseFloat(modalPrice.value) || 0;
            const maxStock = parseInt(activeProductData.remaining_qty);

            if (qty <= 0) { alert('Quantity must be greater than 0.'); return; }
            if (qty > maxStock) { alert(`Only ${maxStock} items available.`); return; }

            const existingIdx = cart.findIndex(c => c.product_id == activeProductData.product_id);
            
            const cartItem = {
                product_id: activeProductData.product_id,
                supplier_id: activeProductData.supplier_id,
                name: activeProductData.name,
                sku: activeProductData.sku || 'N/A',
                sell_price: price,
                quantity: qty,
                dis_type: modalDisType.value,
                dis_value: parseFloat(modalDisValue.value) || 0,
                max_stock: maxStock
            };

            if (existingIdx > -1) {
                cart[existingIdx] = cartItem;
            } else {
                cart.push(cartItem);
            }

            // Save to localStorage immediately so it's accessible in create_order.php
            localStorage.setItem('fintrix_rep_pos_cart', JSON.stringify(cart));
            
            updateCartUI();
            prodModal.hide();
        });

        function updateCartUI() {
            let subtotal = 0;
            let totalItems = 0;

            cart.forEach((item) => {
                totalItems++;
                const gross = item.sell_price * item.quantity;
                let itemDisAmt = item.dis_type === '%' ? (gross * (item.dis_value / 100)) : (item.dis_value * item.quantity);
                subtotal += (gross - itemDisAmt);
            });

            if (totalItems > 0) {
                cartBtn.classList.remove('d-none');
                countBadge.textContent = totalItems;
                totalBtnText.textContent = subtotal.toFixed(2);
            } else {
                cartBtn.classList.add('d-none');
            }
        }

        // Send to POS
        cartBtn.addEventListener('click', function() {
            window.location.href = 'create_order.php<?php echo !$assignment_id ? "?general=true" : ""; ?>';
        });

    });
    </script>
</body>
</html>