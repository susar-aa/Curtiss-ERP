<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/db.php';
require_once '../includes/auth_check.php';
requireRole(['rep']); // Strictly for Sales Reps

$rep_id = $_SESSION['user_id'];

// --- FILTERING ---
$route_filter = isset($_GET['route_id']) ? $_GET['route_id'] : '';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

$whereClause = "rr.rep_id = ?";
$params = [$rep_id];

if ($route_filter !== '') {
    $whereClause .= " AND rr.route_id = ?";
    $params[] = $route_filter;
}
if ($date_from !== '') {
    $whereClause .= " AND rr.assign_date >= ?";
    $params[] = $date_from;
}
if ($date_to !== '') {
    $whereClause .= " AND rr.assign_date <= ?";
    $params[] = $date_to;
}

// Fetch Rep's Route History
$query = "
    SELECT rr.*, r.name as route_name,
           (SELECT COUNT(id) FROM orders WHERE assignment_id = rr.id) as bills_count,
           (SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE assignment_id = rr.id) as gross_sales,
           (SELECT COALESCE(SUM(amount), 0) FROM route_expenses WHERE assignment_id = rr.id) as total_expenses
    FROM rep_routes rr 
    JOIN routes r ON rr.route_id = r.id 
    WHERE $whereClause 
    ORDER BY rr.assign_date DESC, rr.id DESC
    LIMIT 50
";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$history = $stmt->fetchAll();

// Fetch Routes for Dropdown
$routes = $pdo->query("SELECT id, name FROM routes ORDER BY name ASC")->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Route History - Rep App</title>
    
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#0d6efd">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        body { background-color: #f4f7f6; padding-bottom: 90px; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; -webkit-tap-highlight-color: transparent; }
        
        .top-nav { background: #0d6efd; color: white; padding: 15px 20px; position: sticky; top: 0; z-index: 1000; box-shadow: 0 4px 15px rgba(13,110,253,0.2); }
        .back-btn { color: white; font-size: 1.2rem; text-decoration: none; margin-right: 15px; }

        .history-card { background: white; border-radius: 16px; padding: 15px; margin-bottom: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.04); border: 1px solid #f8f9fa; position: relative; overflow: hidden; }
        .history-card.active-route { border-left: 5px solid #198754; }
        .history-card.completed-route { border-left: 5px solid #0d6efd; }
        .history-card.rejected-route { border-left: 5px solid #dc3545; opacity: 0.8; }
        
        .bottom-nav { position: fixed; bottom: 0; left: 0; right: 0; background: white; box-shadow: 0 -4px 15px rgba(0,0,0,0.05); display: flex; justify-content: space-around; padding: 12px 0 8px 0; z-index: 1000; border-top-left-radius: 20px; border-top-right-radius: 20px; }
        .nav-item { text-align: center; color: #adb5bd; text-decoration: none; font-size: 0.75rem; flex: 1; }
        .nav-item.active { color: #0d6efd; font-weight: 700; }
        .nav-item i { font-size: 1.4rem; display: block; margin-bottom: 3px; }
        .nav-item.fab-button { position: relative; top: -20px; }
        .nav-item.fab-button .fab-icon { background: #0d6efd; color: white; width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 3px auto; box-shadow: 0 4px 10px rgba(13,110,253,0.3); font-size: 1.5rem; }
    </style>
</head>
<body>

    <div class="top-nav d-flex align-items-center">
        <a href="dashboard.php" class="back-btn"><i class="bi bi-arrow-left"></i></a>
        <div>
            <h5 class="mb-0 fw-bold">Route History</h5>
            <small class="text-white text-opacity-75">My Past Trips</small>
        </div>
    </div>

    <div class="container px-3 mt-3">
        
        <!-- Filter Section -->
        <div class="bg-white p-3 rounded-4 shadow-sm mb-4 border">
            <h6 class="fw-bold small text-muted text-uppercase mb-2"><i class="bi bi-funnel"></i> Filter Records</h6>
            <form method="GET" action="" id="filterForm">
                <div class="mb-2">
                    <select name="route_id" class="form-select bg-light border-0 fw-bold text-dark" onchange="document.getElementById('filterForm').submit();">
                        <option value="">All Routes</option>
                        <?php foreach($routes as $r): ?>
                            <option value="<?php echo $r['id']; ?>" <?php echo $route_filter == $r['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($r['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="row g-2">
                    <div class="col-6">
                        <input type="date" name="date_from" class="form-control bg-light border-0 small" value="<?php echo htmlspecialchars($date_from); ?>" onchange="document.getElementById('filterForm').submit();">
                    </div>
                    <div class="col-6">
                        <input type="date" name="date_to" class="form-control bg-light border-0 small" value="<?php echo htmlspecialchars($date_to); ?>" onchange="document.getElementById('filterForm').submit();">
                    </div>
                </div>
                <?php if($route_filter || $date_from || $date_to): ?>
                    <a href="route_history.php" class="btn btn-sm btn-outline-danger w-100 mt-2 rounded-pill fw-bold">Clear Filters</a>
                <?php endif; ?>
            </form>
        </div>

        <?php if (empty($history)): ?>
            <div class="alert alert-info border-0 shadow-sm rounded-4 text-center p-4 mt-4">
                <i class="bi bi-journal-x fs-1 d-block mb-2 text-info"></i>
                <h6 class="fw-bold">No History Found</h6>
                <p class="small mb-0">You have no assigned routes matching these filters.</p>
            </div>
        <?php else: ?>
            
            <div class="d-flex justify-content-between align-items-center mb-3 px-1">
                <span class="text-muted fw-bold small text-uppercase">Records (<?php echo count($history); ?>)</span>
            </div>

            <?php foreach ($history as $h): 
                $cardClass = 'history-card';
                if(in_array($h['status'], ['assigned', 'accepted'])) $cardClass .= ' active-route';
                elseif(in_array($h['status'], ['completed', 'unloaded'])) $cardClass .= ' completed-route';
                else $cardClass .= ' rejected-route';
            ?>
            <div class="<?php echo $cardClass; ?>">
                <div class="d-flex justify-content-between align-items-start border-bottom pb-2 mb-2">
                    <div>
                        <div class="small fw-bold text-muted"><i class="bi bi-calendar-event"></i> <?php echo date('D, M d, Y', strtotime($h['assign_date'])); ?></div>
                        <h6 class="fw-bold text-dark mb-0 mt-1 fs-5"><?php echo htmlspecialchars($h['route_name']); ?></h6>
                    </div>
                    <div class="text-end">
                        <?php if(in_array($h['status'], ['completed', 'unloaded'])): ?>
                            <span class="badge bg-success bg-opacity-10 text-success border border-success px-2 py-1"><i class="bi bi-check-circle"></i> Closed</span>
                        <?php elseif(in_array($h['status'], ['assigned', 'accepted'])): ?>
                            <span class="badge bg-warning bg-opacity-10 text-dark border border-warning px-2 py-1"><i class="bi bi-play-circle"></i> Active</span>
                        <?php else: ?>
                            <span class="badge bg-danger bg-opacity-10 text-danger border border-danger px-2 py-1"><i class="bi bi-x-circle"></i> Rejected</span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row text-center mt-3 mb-3">
                    <div class="col-4 border-end">
                        <div class="text-muted" style="font-size: 0.7rem; font-weight: bold; text-transform: uppercase;">Bills</div>
                        <div class="fw-bold fs-5 text-dark"><?php echo $h['bills_count']; ?></div>
                    </div>
                    <div class="col-8">
                        <div class="text-muted" style="font-size: 0.7rem; font-weight: bold; text-transform: uppercase;">Gross Sales</div>
                        <div class="fw-bold fs-5 text-success">Rs: <?php echo number_format($h['gross_sales'], 2); ?></div>
                    </div>
                </div>
                
                <?php if($h['total_expenses'] > 0): ?>
                <div class="bg-danger bg-opacity-10 text-danger p-2 rounded mb-3 small fw-bold d-flex justify-content-between">
                    <span><i class="bi bi-wallet2"></i> Recorded Expenses:</span>
                    <span>- Rs: <?php echo number_format($h['total_expenses'], 2); ?></span>
                </div>
                <?php endif; ?>

                <?php if($h['status'] != 'rejected'): ?>
                    <a href="todays_bills.php?assignment_id=<?php echo $h['id']; ?>" class="btn btn-outline-primary w-100 rounded-pill fw-bold shadow-sm py-2">
                        <i class="bi bi-receipt me-1"></i> View Route Bills
                    </a>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>

        <?php endif; ?>
    </div>

    <!-- Mobile Bottom Navigation -->
    <div class="bottom-nav">
        <a href="dashboard.php" class="nav-item">
            <i class="bi bi-house-door-fill"></i> Home
        </a>
        <a href="customers.php?filter=route" class="nav-item">
            <i class="bi bi-people-fill"></i> Clients
        </a>
        <a href="create_order.php" class="nav-item fab-button">
            <div class="fab-icon"><i class="bi bi-receipt mt-1"></i></div>
            <span class="text-dark fw-bold">POS</span>
        </a>
        <a href="route_history.php" class="nav-item active">
            <i class="bi bi-clock-history"></i> History
        </a>
        <a href="../pages/product_gallery.php" class="nav-item">
            <i class="bi bi-grid-fill"></i> Catalog
        </a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>