<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config/db.php';
require_once '../includes/auth_check.php';
requireRole(['rep']); // Strictly for Sales Reps

$rep_id = $_SESSION['user_id'];
$message = '';

// --- AUTO DB MIGRATION FOR LOCATION FIELDS ---
try {
    $pdo->exec("ALTER TABLE customers ADD COLUMN latitude DECIMAL(10, 8) NULL");
    $pdo->exec("ALTER TABLE customers ADD COLUMN longitude DECIMAL(11, 8) NULL");
} catch(PDOException $e) {}

// --- Handle Add Customer POST ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add_customer') {
    $name = trim($_POST['name']);
    $owner_name = trim($_POST['owner_name']);
    $phone = trim($_POST['phone']);
    $whatsapp = trim($_POST['whatsapp']);
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address']);
    $route_id = !empty($_POST['route_id']) ? (int)$_POST['route_id'] : null;
    $latitude = !empty($_POST['latitude']) ? (float)$_POST['latitude'] : null;
    $longitude = !empty($_POST['longitude']) ? (float)$_POST['longitude'] : null;

    if (!empty($name)) {
        $stmt = $pdo->prepare("INSERT INTO customers (name, owner_name, phone, whatsapp, email, address, rep_id, route_id, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if ($stmt->execute([$name, $owner_name, $phone, $whatsapp, $email, $address, $rep_id, $route_id, $latitude, $longitude])) {
            $message = "<div class='alert-banner success'><i class='bi bi-check-circle-fill'></i> Customer added successfully!</div>";
        } else {
            $message = "<div class='alert-banner error'><i class='bi bi-exclamation-triangle-fill'></i> Error adding customer.</div>";
        }
    }
}

// Check which filter is active
$filter = isset($_GET['filter']) && $_GET['filter'] === 'all' ? 'all' : 'route';

// --- 1. Fetch Today's Active Route ---
$routeStmt = $pdo->prepare("
    SELECT r.id as route_id, r.name as route_name 
    FROM rep_routes rr 
    JOIN routes r ON rr.route_id = r.id 
    WHERE rr.rep_id = ? AND rr.assign_date = CURDATE() AND rr.status = 'accepted' AND rr.start_meter IS NOT NULL
    ORDER BY rr.id DESC LIMIT 1
");
$routeStmt->execute([$rep_id]);
$active_route = $routeStmt->fetch();

// --- 2. Build Query & Fetch Customers ---
$whereClauseParts = [];
$params = [];

if ($filter === 'route') {
    if ($active_route) {
        $whereClauseParts[] = "c.route_id = ?";
        $params[] = $active_route['route_id'];
    } else {
        $whereClauseParts[] = "1 = 0"; // Force 0 results if no active route
    }
}

$whereSql = "";
if (count($whereClauseParts) > 0) {
    $whereSql = "WHERE " . implode(' AND ', $whereClauseParts);
}

$custStmt = $pdo->prepare("
    SELECT c.*, 
           (SELECT COALESCE(SUM(total_amount - paid_amount), 0) FROM orders WHERE customer_id = c.id) as outstanding 
    FROM customers c 
    $whereSql 
    ORDER BY c.name ASC
");
$custStmt->execute($params);
$customers = $custStmt->fetchAll();

// Fetch all routes for the Add Customer form
$routes = $pdo->query("SELECT id, name FROM routes ORDER BY name ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Customers — Fintrix</title>
    
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#111110">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        /* Exact Theme Variables from Dashboard */
        :root {
            --bg: #f7f7f5;
            --surface: #ffffff;
            --surface-2: #f0efec;
            --border: #e4e2dd;
            --border-strong: #ccc9c2;
            --text-primary: #111110;
            --text-secondary: #78746c;
            --text-tertiary: #a8a49c;
            --accent: #e8650a;
            --accent-light: #fef0e7;
            --green: #1a7a4a;
            --green-light: #e8f5ee;
            --red: #c0392b;
            --red-light: #fcecea;
            --blue: #1a5ca8;
            --blue-light: #e8f0fb;
            --amber: #b45309;
            --amber-light: #fef3e2;
            --radius: 14px;
            --radius-sm: 8px;
            --nav-h: 68px;
        }

        * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }

        body {
            background: var(--bg);
            font-family: 'DM Sans', sans-serif;
            color: var(--text-primary);
            padding-bottom: calc(var(--nav-h) + 16px);
            -webkit-font-smoothing: antialiased;
            margin: 0;
        }

        /* ── Header ── */
        .sub-header {
            background: var(--text-primary);
            padding: 16px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0; z-index: 100;
        }
        .btn-header {
            color: #fff; font-size: 24px; text-decoration: none;
            width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;
            margin-left: -10px; border-radius: 50%; transition: background 0.15s;
            background: transparent; border: none;
        }
        .btn-header:active { background: rgba(255,255,255,0.1); }
        .header-stack { flex: 1; text-align: center; }
        .sub-header-title { color: #fff; font-size: 16px; font-weight: 700; margin: 0; line-height: 1.2; }
        .sub-header-meta { font-size: 11px; color: rgba(255,255,255,0.6); font-family: 'DM Mono', monospace; }

        /* ── Alert Banner ── */
        .alert-banner { padding: 12px 16px; font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 8px; border-bottom: 1px solid var(--border); }
        .alert-banner.success { background: var(--green-light); color: var(--green); border-color: rgba(26,122,74,0.2); }
        .alert-banner.error { background: var(--red-light); color: var(--red); border-color: rgba(192,57,43,0.2); }

        /* ── Toggles & Search ── */
        .search-area {
            background: var(--surface);
            padding: 12px 16px;
            border-bottom: 1px solid var(--border);
            position: sticky;
            top: 72px; /* Approx header height */
            z-index: 99;
        }
        .filter-toggle {
            display: flex; background: var(--surface-2); border-radius: 100px; padding: 4px; margin-bottom: 12px;
        }
        .filter-btn {
            flex: 1; text-align: center; padding: 8px 0; font-size: 13px; font-weight: 600; border-radius: 100px;
            text-decoration: none; color: var(--text-secondary); transition: all 0.15s;
        }
        .filter-btn.active { background: var(--surface); color: var(--text-primary); box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        
        .search-box { position: relative; display: flex; align-items: center; }
        .search-icon { position: absolute; left: 14px; color: var(--text-tertiary); font-size: 15px; }
        .search-input {
            width: 100%; background: var(--surface-2); border: 1.5px solid transparent; border-radius: 100px;
            padding: 10px 40px; font-size: 14px; font-family: 'DM Sans', sans-serif; color: var(--text-primary); outline: none;
            transition: border-color 0.15s, background 0.15s;
        }
        .search-input:focus { background: var(--surface); border-color: var(--accent); }
        .clear-btn { position: absolute; right: 14px; color: var(--text-tertiary); background: none; border: none; padding: 0; font-size: 16px; }

        /* ── Content Area ── */
        .page-content { padding: 16px; }
        .results-meta { font-size: 11px; font-weight: 700; color: var(--text-tertiary); text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 12px; }

        /* ── Customer Card ── */
        .cust-card {
            background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
            padding: 16px; margin-bottom: 12px;
        }
        .cust-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px; }
        .cust-name { font-size: 16px; font-weight: 700; color: var(--text-primary); margin-bottom: 2px; }
        .cust-address { font-size: 12px; color: var(--text-secondary); display: flex; align-items: flex-start; gap: 4px; line-height: 1.4; }
        
        .tag { display: inline-flex; align-items: center; gap: 4px; font-size: 10px; font-weight: 700; text-transform: uppercase; padding: 4px 8px; border-radius: 6px; letter-spacing: 0.05em; font-family: 'DM Mono', monospace; }
        .tag.danger { background: var(--red-light); color: var(--red); }
        .tag.success { background: var(--green-light); color: var(--green); }

        .cust-actions { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; border-top: 1px solid var(--border); padding-top: 12px; margin-top: 4px; }
        .btn-act {
            background: var(--surface-2); color: var(--text-primary); text-decoration: none; border: none;
            padding: 10px 0; border-radius: var(--radius-sm); font-size: 12px; font-weight: 600;
            display: flex; align-items: center; justify-content: center; gap: 6px; transition: background 0.15s;
        }
        .btn-act:active { background: var(--border); }
        .btn-act.disabled { opacity: 0.4; pointer-events: none; }
        .btn-act i.ic-call { color: var(--blue); font-size: 14px; }
        .btn-act i.ic-chat { color: var(--green); font-size: 14px; }
        .btn-act i.ic-prof { color: var(--text-primary); font-size: 14px; }

        /* ── Notices ── */
        .notice-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 24px 20px; text-align: center; }
        .notice-icon { font-size: 40px; color: var(--text-tertiary); margin-bottom: 12px; }
        .notice-title { font-size: 15px; font-weight: 700; margin-bottom: 4px; }
        .notice-sub { font-size: 13px; color: var(--text-secondary); line-height: 1.5; }

        /* ── Offcanvas Form ── */
        .offcanvas-bottom { border-radius: 24px 24px 0 0 !important; border: none; height: 85vh !important; font-family: 'DM Sans', sans-serif; box-shadow: 0 -8px 40px rgba(0,0,0,0.12); }
        .offcanvas-header { padding: 20px; border-bottom: 1px solid var(--border); }
        .offcanvas-title { font-size: 16px; font-weight: 700; }
        .form-label-sm { font-size: 10px; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text-tertiary); margin-bottom: 6px; display: block; }
        .form-ctrl {
            width: 100%; background: var(--surface-2); border: 1.5px solid var(--border); border-radius: var(--radius-sm);
            padding: 12px 14px; font-size: 14px; font-family: 'DM Sans', sans-serif; color: var(--text-primary);
            outline: none; transition: border-color 0.15s;
        }
        .form-ctrl:focus { border-color: var(--accent); }
        .form-ctrl::placeholder { color: var(--text-tertiary); }
        select.form-ctrl { appearance: none; background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23a8a49c%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E"); background-repeat: no-repeat; background-position: right 14px top 50%; background-size: 10px auto; padding-right: 30px; }
        
        .btn-full {
            width: 100%; border: none; border-radius: var(--radius-sm); padding: 14px; font-size: 14px; font-weight: 700;
            font-family: 'DM Sans', sans-serif; cursor: pointer; transition: opacity 0.15s, transform 0.1s;
        }
        .btn-full:active { opacity: 0.85; transform: scale(0.99); }
        .btn-full.dark { background: var(--text-primary); color: #fff; }
        .btn-full.outline { background: transparent; border: 1.5px solid var(--border); color: var(--text-primary); }

        /* ── Bottom Nav ── */
        .bottom-nav {
            position: fixed; bottom: 0; left: 0; right: 0; background: var(--surface); border-top: 1px solid var(--border);
            display: flex; justify-content: space-around; align-items: center; height: var(--nav-h); z-index: 1000;
            padding-bottom: env(safe-area-inset-bottom, 0);
        }
        .nav-tab {
            flex: 1; display: flex; flex-direction: column; align-items: center; gap: 4px; text-decoration: none;
            color: var(--text-tertiary); font-size: 10px; font-weight: 500; letter-spacing: 0.04em; padding: 8px 0; transition: color 0.15s;
        }
        .nav-tab i { font-size: 20px; }
        .nav-tab.active { color: var(--text-primary); }
        .nav-tab.active i { color: var(--accent); }
        .nav-fab { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 4px; text-decoration: none; }
        .fab-circle {
            width: 46px; height: 46px; border-radius: 50%; background: var(--text-primary);
            display: flex; align-items: center; justify-content: center; font-size: 20px; color: #fff;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2); margin-top: -16px;
        }
        .fab-label { font-size: 10px; color: var(--text-secondary); font-weight: 600; margin-top: -2px; }
    </style>
</head>
<body>

    <!-- Header -->
    <div class="sub-header">
        <a href="dashboard.php" class="btn-header"><i class="bi bi-arrow-left-short"></i></a>
        <div class="header-stack">
            <h1 class="sub-header-title"><?php echo $filter === 'all' ? 'All Customers' : 'Route Customers'; ?></h1>
            <?php if($filter === 'route' && $active_route): ?>
                <div class="sub-header-meta"><?php echo htmlspecialchars($active_route['route_name']); ?></div>
            <?php elseif($filter === 'all'): ?>
                <div class="sub-header-meta">Company Directory</div>
            <?php endif; ?>
        </div>
        <button class="btn-header" data-bs-toggle="offcanvas" data-bs-target="#addCustomerCanvas">
            <i class="bi bi-person-plus"></i>
        </button>
    </div>

    <?php echo $message; ?>

    <!-- Toggles & Search -->
    <div class="search-area">
        <div class="filter-toggle">
            <a href="customers.php?filter=route" class="filter-btn <?php echo $filter === 'route' ? 'active' : ''; ?>">Active Route</a>
            <a href="customers.php?filter=all" class="filter-btn <?php echo $filter === 'all' ? 'active' : ''; ?>">All Clients</a>
        </div>
        <div class="search-box">
            <i class="bi bi-search search-icon"></i>
            <input type="text" id="liveSearchInput" class="search-input" placeholder="Search name, address...">
            <button type="button" class="clear-btn d-none" id="clearSearchBtn"><i class="bi bi-x-circle-fill"></i></button>
        </div>
    </div>

    <!-- Content Area -->
    <div class="page-content">
        
        <?php if ($filter === 'route' && !$active_route): ?>
            <div class="notice-card">
                <i class="bi bi-signpost-split notice-icon"></i>
                <div class="notice-title">No Active Route</div>
                <div class="notice-sub">You must accept a route and start your day to view the customers assigned to it.</div>
            </div>
        <?php elseif (empty($customers)): ?>
            <div class="notice-card">
                <i class="bi bi-people notice-icon"></i>
                <div class="notice-title">No Customers Found</div>
                <div class="notice-sub">There are no customers currently available in this view.</div>
            </div>
        <?php else: ?>
            
            <div class="results-meta">
                Showing <span id="resultsCount"><?php echo count($customers); ?></span> Customers
            </div>

            <div id="customersContainer">
                <?php foreach ($customers as $c): 
                    $whatsapp_raw = $c['whatsapp'] ?? '';
                    $whatsapp_clean = preg_replace('/[^0-9]/', '', $whatsapp_raw);
                    if (strlen($whatsapp_clean) == 10 && str_starts_with($whatsapp_clean, '0')) {
                        $whatsapp_clean = '94' . substr($whatsapp_clean, 1); 
                    }
                ?>
                <div class="cust-card">
                    <div class="cust-header">
                        <div>
                            <div class="cust-name"><?php echo htmlspecialchars($c['name']); ?></div>
                            <div class="cust-address text-truncate" style="max-width: 220px;">
                                <i class="bi bi-geo-alt" style="margin-top:2px;"></i> 
                                <?php echo htmlspecialchars($c['address'] ?: 'No Address'); ?>
                            </div>
                            <div class="d-none customer-phone"><?php echo htmlspecialchars($c['phone']); ?></div>
                        </div>
                        <?php if($c['outstanding'] > 0): ?>
                            <div class="tag danger"><i class="bi bi-exclamation-circle-fill"></i> Rs <?php echo number_format($c['outstanding']); ?></div>
                        <?php else: ?>
                            <div class="tag success"><i class="bi bi-check-circle-fill"></i> Cleared</div>
                        <?php endif; ?>
                    </div>

                    <div class="cust-actions">
                        <a href="tel:<?php echo htmlspecialchars($c['phone']); ?>" class="btn-act <?php echo !$c['phone'] ? 'disabled' : ''; ?>">
                            <i class="bi bi-telephone-fill ic-call"></i> Call
                        </a>
                        <a href="https://wa.me/<?php echo $whatsapp_clean; ?>" target="_blank" class="btn-act <?php echo !$c['whatsapp'] ? 'disabled' : ''; ?>">
                            <i class="bi bi-whatsapp ic-chat"></i> Chat
                        </a>
                        <a href="../pages/view_customer.php?id=<?php echo $c['id']; ?>" class="btn-act">
                            <i class="bi bi-person-vcard ic-prof"></i> Profile
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div id="noResultsMsg" class="notice-card d-none">
                <i class="bi bi-search notice-icon"></i>
                <div class="notice-title">No Matches</div>
                <div class="notice-sub">No customers match your search query.</div>
            </div>

        <?php endif; ?>
    </div>

    <!-- Offcanvas Add Customer -->
    <div class="offcanvas offcanvas-bottom" tabindex="-1" id="addCustomerCanvas">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title">New Customer</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body" style="padding: 20px;">
            <form method="POST">
                <input type="hidden" name="action" value="add_customer">
                
                <div style="margin-bottom:16px;">
                    <label class="form-label-sm">Business Name *</label>
                    <input type="text" name="name" class="form-ctrl" required placeholder="e.g. City Mart" style="font-weight:600;">
                </div>
                
                <div style="margin-bottom:16px;">
                    <label class="form-label-sm">Owner Name</label>
                    <input type="text" name="owner_name" class="form-ctrl" placeholder="Optional">
                </div>

                <div style="display:flex; gap:12px; margin-bottom:16px;">
                    <div style="flex:1;">
                        <label class="form-label-sm">Phone</label>
                        <input type="tel" name="phone" class="form-ctrl" placeholder="07xxxxxxxx">
                    </div>
                    <div style="flex:1;">
                        <label class="form-label-sm">WhatsApp</label>
                        <input type="tel" name="whatsapp" class="form-ctrl" placeholder="07xxxxxxxx">
                    </div>
                </div>

                <div style="margin-bottom:16px;">
                    <label class="form-label-sm">Email Address</label>
                    <input type="email" name="email" class="form-ctrl" placeholder="Optional">
                </div>

                <div style="margin-bottom:16px;">
                    <label class="form-label-sm">Assign to Route</label>
                    <select name="route_id" class="form-ctrl">
                        <option value="">-- Select Route --</option>
                        <?php foreach($routes as $r): ?>
                            <option value="<?php echo $r['id']; ?>" <?php echo ($active_route && $active_route['route_id'] == $r['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($r['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="margin-bottom:16px;">
                    <label class="form-label-sm">Address</label>
                    <textarea name="address" class="form-ctrl" rows="2" placeholder="Street, City..."></textarea>
                </div>

                <div style="display:flex; gap:12px; margin-bottom:12px;">
                    <div style="flex:1;">
                        <label class="form-label-sm">Latitude</label>
                        <input type="text" name="latitude" id="cust_lat" class="form-ctrl" style="font-family:'DM Mono', monospace; font-size:12px;" placeholder="Lat">
                    </div>
                    <div style="flex:1;">
                        <label class="form-label-sm">Longitude</label>
                        <input type="text" name="longitude" id="cust_lng" class="form-ctrl" style="font-family:'DM Mono', monospace; font-size:12px;" placeholder="Lng">
                    </div>
                </div>
                
                <button type="button" class="btn-full outline" style="margin-bottom:24px; padding:10px; font-size:12px;" onclick="getLocation()">
                    <i class="bi bi-geo-alt"></i> Get Current Location
                </button>

                <button type="submit" class="btn-full dark">Save Customer</button>
            </form>
        </div>
    </div>

    <!-- Bottom Nav -->
    <nav class="bottom-nav">
        <a href="dashboard.php" class="nav-tab">
            <i class="bi bi-house-door-fill"></i> Home
        </a>
        <a href="customers.php?filter=route" class="nav-tab active">
            <i class="bi bi-people-fill"></i> Clients
        </a>
        <a href="create_order.php" class="nav-fab">
            <div class="fab-circle"><i class="bi bi-receipt"></i></div>
            <span class="fab-label">POS</span>
        </a>
        <a href="todays_bills.php" class="nav-tab">
            <i class="bi bi-clock-history"></i> History
        </a>
        <a href="catalog.php" class="nav-tab">
            <i class="bi bi-grid-fill"></i> Catalog
        </a>
    </nav>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('liveSearchInput');
            const clearBtn = document.getElementById('clearSearchBtn');
            const cards = document.querySelectorAll('.cust-card');
            const countEl = document.getElementById('resultsCount');
            const noResultsMsg = document.getElementById('noResultsMsg');

            if (searchInput) {
                searchInput.addEventListener('input', function() {
                    const term = this.value.toLowerCase();
                    
                    if (term.length > 0) {
                        clearBtn.classList.remove('d-none');
                    } else {
                        clearBtn.classList.add('d-none');
                    }

                    let visibleCount = 0;
                    cards.forEach(card => {
                        const text = card.innerText.toLowerCase();
                        if (text.includes(term)) {
                            card.style.display = 'block';
                            visibleCount++;
                        } else {
                            card.style.display = 'none';
                        }
                    });
                    
                    if (countEl) countEl.textContent = visibleCount;
                    
                    if (visibleCount === 0 && cards.length > 0) {
                        noResultsMsg.classList.remove('d-none');
                    } else if (noResultsMsg) {
                        noResultsMsg.classList.add('d-none');
                    }
                });

                clearBtn.addEventListener('click', function() {
                    searchInput.value = '';
                    searchInput.dispatchEvent(new Event('input'));
                    searchInput.focus();
                });
            }

            const addCustomerCanvas = document.getElementById('addCustomerCanvas');
            if (addCustomerCanvas) {
                addCustomerCanvas.addEventListener('shown.bs.offcanvas', function () {
                    if (!document.getElementById('cust_lat').value) getLocation();
                });
            }
        });

        function getLocation() {
            if (navigator.geolocation) {
                document.getElementById('cust_lat').value = 'Locating...';
                document.getElementById('cust_lng').value = 'Locating...';
                navigator.geolocation.getCurrentPosition(function(position) {
                    document.getElementById('cust_lat').value = position.coords.latitude.toFixed(6);
                    document.getElementById('cust_lng').value = position.coords.longitude.toFixed(6);
                }, function(error) {
                    alert("Error fetching location. You can enter it manually.");
                    document.getElementById('cust_lat').value = '';
                    document.getElementById('cust_lng').value = '';
                }, { enableHighAccuracy: true });
            } else {
                alert("Geolocation is not supported by this browser.");
            }
        }
    </script>
</body>
</html>